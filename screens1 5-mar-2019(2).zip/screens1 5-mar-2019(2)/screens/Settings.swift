import UIKit

class Settings: UIViewController,UITableViewDataSource,UITableViewDelegate {
   
    let arr = ["edit profile","videos/images","logout"]

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    func getPath() -> String {
        
        let arr = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        let path = arr[0]
        let finalPath = path.appending("/userLogin.plist")
        print(finalPath)
        return finalPath
    }
    func destroyLoginData() {
        
        let flm = FileManager()
        if flm.fileExists(atPath: getPath()) {
            
            var disc = NSDictionary(contentsOfFile: getPath()) as! [String:Any]
            var arr = disc["userRecord"] as! [[String:Any]]
            arr.removeAll()
            disc["userRecord"] = arr
            let finalDisc = NSDictionary(dictionary: disc)
            finalDisc.write(toFile: getPath(), atomically: true)
            
        }
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arr.count;
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        cell.textLabel?.text = arr[indexPath.row];
        return cell;
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print(arr[indexPath.row])
        if arr[indexPath.row] == "logout"{
            destroyLoginData();
            let stb = self.storyboard?.instantiateViewController(withIdentifier: "login") as! ViewController
            self.navigationController?.pushViewController(stb, animated: true)
        }
        if arr[indexPath.row] == "videos/images"{
            
        }
        
        
    }
}
