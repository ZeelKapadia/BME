import UIKit
import AVFoundation
import AVKit
import SDWebImage

class GiveYourVotes: UIViewController,UITableViewDataSource,UITableViewDelegate,FetchDelegate,WriteDelegate {
    
    var aoForPosts : [[String:Any]] = []
    var V_Status = ""
    var eid = ""
    var O_id = ""
    var Vm_id = ""
    var user_id = ""
    var pa_id = ""
    var temp  : [String:String] = [:]
    var negcount = 0;
    var P_id = ""
    var poscount = 0;
    var flag = 0;
    
    @IBOutlet weak var tblFetchPosts: UITableView!
    @IBOutlet weak var btnHome: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        getLoginData()
        fetchdata()
        self.tabBarController?.tabBar.isHidden = true;
        btnHome.layer.cornerRadius = btnHome.layer.frame.height / 2;
        btnHome.clipsToBounds = true
    }
    func fetchdata() {
        let objc = dataFetch()
        objc.delegate = self
        let disc = ["user_id":user_id]
        objc.getUniqueData(FileName: "UploadFetch.php", DiscData: disc)
    }
    func getUniqueData(arrDisc: [[String : Any]]) {
        if arrDisc.count > 0 {
            aoForPosts = arrDisc
            tblFetchPosts.reloadData()
        }
    }
    func getResponseData(arrDisc: [[String : Any]]) {
        
    }
    
    func getResponseDataAgain(arrDisc: [[String : Any]]) {
        
    }
    
    func putDictionary(str: String) {
        print(str)
        if str == "already given Vote\r\n\r\n"{
            let alt = UIAlertController(title: "Vote can not be given", message: "The vote is already registered", preferredStyle: .actionSheet)
            let ok = UIAlertAction(title: "ok", style: .default, handler: nil)
            alt.addAction(ok)
            self.present(alt, animated: true, completion: nil)
        }
        else if str == "success\r\n\r\n"{
            let alt = UIAlertController(title:"Vote is registered", message:"Thanks for giving your vote", preferredStyle:.actionSheet)
            let ok = UIAlertAction(title: "ok", style: .default, handler: nil)
            alt.addAction(ok)
            self.present(alt, animated: true, completion: nil)
        }
        fetchdata()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return aoForPosts.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
       let discForPost = aoForPosts[indexPath.row]
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! CellForGiveVotes
        cell.posVote.tag = indexPath.row
        cell.nagVote.tag = indexPath.row
        cell.lbl_name.text = discForPost["pa_name"] as? String
        let E_id = discForPost["e_id"] as! String
        pa_id = discForPost["pa_id"] as! String
        P_id = discForPost["P_id"] as! String
        let u_id = discForPost["user_id"] as! String
        
        check(u_id: user_id, P_id: P_id, tag: indexPath.row)
        
        let type = discForPost["Post_type"] as! String
        print(type)
       
        
        
            if E_id == eid {
                if type == "Image"{
                    cell.btnplay.isHidden = true
                    let name = discForPost["Image_data"] as! String
                    let str = "http://localhost/votingdb/"
                    let url = URL(string: str + name)
                    do{
                        let data = try Data(contentsOf: url!)
                        cell.imgVideoImage.image = UIImage(data: data)
                    }catch{}
                }
                if type == "Video"{
                    //      let temp = aoForPosts[indexPath.row] as! [String:String]
                    let str = "http://localhost/votingdb/"
                    let videoPath = discForPost["video_data"] as! String
                    temp = discForPost as! [String : String]
                    let url = URL(string: str + videoPath)
                    let img = getThumbnailImage(forUrl: url!)
                    cell.imgVideoImage.image = img
                    cell.btnplay.isHidden = false
                    cell.btnplay.addTarget(self, action: #selector(self.play), for: .touchUpInside)
                }
            }
        if user_id == u_id {
        cell.posVote.isEnabled = false
            cell.nagVote.isEnabled = false
        }
            cell.posVote.addTarget(self, action: #selector(self.positive), for:.touchUpInside)
            cell.nagVote.addTarget(self, action: #selector(self.negative), for: .touchUpInside)
        
        
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 390.0
    }
    func play() {
        let str = "http://localhost/votingdb/"
        let videoPath = temp["video_data"]
        let fullPath = str.appending(videoPath!)
        let videoURL = URL(string: fullPath)
        let player = AVPlayer(url: videoURL!)
        let playerViewController = AVPlayerViewController()
        playerViewController.player = player
        self.present(playerViewController, animated: true) {
            playerViewController.player!.play()
    }
    }
    func positive() {
        flag = 0;
        poscount = poscount + 1
        let obj = dataWrite()
        obj.delegate = self
        let discForWriteInDataBase = ["flag":flag,"E_id":eid,"Vm_id":Vm_id,"Pa_id":pa_id,"user_id":user_id,"poitive" : poscount,"P_id" : P_id] as [String : Any]
        obj.WriteData(FileName: "votes.php", DiscData: discForWriteInDataBase)
        
        
    }
    func negative() {
        flag = 1;
        negcount = negcount + 1
        let obj = dataWrite()
        obj.delegate = self
        let discForWriteInDataBase = ["flag":flag,"E_id":eid,"Vm_id":Vm_id,"Pa_id":pa_id,"user_id":user_id,"negative" : negcount,"P_id":P_id] as [String : Any]
        obj.WriteData(FileName: "votes.php", DiscData: discForWriteInDataBase)
    
    }
    func getThumbnailImage(forUrl url: URL) -> UIImage? {
        let asset: AVAsset = AVAsset(url: url)
        let imageGenerator = AVAssetImageGenerator(asset: asset)
        
        do {
            let thumbnailImage = try imageGenerator.copyCGImage(at: CMTimeMake(1, 60) , actualTime: nil)
            return UIImage(cgImage: thumbnailImage)
        } catch let error {
            print(error)
        }
        
        return nil
    }
    func getPath() -> String {
        
        let arr = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        let path = arr[0]
        let finalPath = path.appending("/userLogin.plist")
        print(finalPath)
        return finalPath
    }
    func getLoginData() {
        
        let flm = FileManager()
        if flm.fileExists(atPath: getPath()) {
            
            var disc = NSDictionary(contentsOfFile: getPath()) as! [String:Any]
      let brr = disc["userRecord"] as! [[String:Any]]
            let getDisc = brr[0];
            user_id = getDisc["user_id"] as! String;
            
        }
    }
    @IBAction func move_to_home_page(_ sender: Any) {
        move()
    }
    func move() {
     self.navigationController?.navigationBar.isHidden = true
    self.tabBarController?.tabBar.isHidden = true
        let stb = self.storyboard?.instantiateViewController(withIdentifier: "Usertab")
        self.navigationController?.pushViewController(stb!, animated: true)
    }
    func check(u_id:String ,P_id :String, tag : Int) {
        
        let str = "http://localhost/votingdb/check.php"
        do {
            let Disc = ["user_id":u_id,"P_id":P_id];
            
            let body = try JSONSerialization.data(withJSONObject: Disc, options: [])
            let url = URL(string: str)
            var request = URLRequest(url: url!)
            request.addValue(String(body.count), forHTTPHeaderField: "Content-Length")
            request.httpBody = body
            request.httpMethod = "POST"
            let session = URLSession.shared
            let datatask = session.dataTask(with: request){ (data1, resp, err) in
                
                let result = String(data: data1!, encoding: String.Encoding.utf8)
                //print(result!)
                
                DispatchQueue.main.async {
                    let indexpath = IndexPath(row: tag, section: 0)
                    if let cell = self.tblFetchPosts.cellForRow(at: indexpath) as? CellForGiveVotes {
                        if result == "Found"{
                            
                            cell.posVote.isEnabled = false
                            cell.nagVote.isEnabled = false
                        }else if result == "NotFound"{
                            
                            cell.nagVote.isEnabled = true
                            cell.posVote.isEnabled = true
                            cell.posVote.addTarget(self, action: #selector(self.positive), for:.touchUpInside)
                            cell.nagVote.addTarget(self, action: #selector(self.negative), for: .touchUpInside)
                        }
                        
                    }
                }
            }
            datatask.resume()
        }catch  {}
    }
}
