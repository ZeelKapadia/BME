//
//  EventsForUser.swift
//  screens
//
//  Created by Zeel Kapadia on 28/01/19.
//  Copyright © 2019 TOPS. All rights reserved.
//

import UIKit

class EventsForUser: UIViewController,UITableViewDelegate,UITableViewDataSource,FetchDelegate {
   
    var arrForEvent : [[String:Any]] = []
    var discForEvent :[String:Any] = [:]

    override func viewDidLoad() {
        super.viewDidLoad()
        createObject()
    }
    func CreateObject() {
        let ObjectFetch = dataFetch()
        ObjectFetch.delegate = self
        ObjectFetch.fetch_data(Filename: "")
    }
    func getResponseData(arrDisc: [[String : Any]]) {
        arrForEvent = arrDisc
    }
    
    func getResponseDataAgain(arrDisc: [[String : Any]]) {
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrForEvent.count;
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        discForEvent = arrForEvent[indexPath.row]
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        cell.textLabel?.text = discForEvent["E_name"];
        return cell;
    }
    

   
}
