import UIKit
import SDWebImage

class user_home_screen: UIViewController,FetchDelegate,DataUpdatedDelegate,UITableViewDelegate,UITableViewDataSource{
    @IBOutlet weak var tbldatashow: UITableView!
    func UpdateAgain(str: String) {
        print(str);
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return Aodisc.count;
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 2;
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let discForHomeScreen = Aodisc[indexPath.section]
        if indexPath.row==0 && indexPath.section == 0{
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! FirstCellForUserHomeScreen
            cell.event_name.text = discForHomeScreen["E_name"] as? String
            let imgName = discForHomeScreen["Banner_image"] as! String
            let str = "http://localhost/votingdb/"
            let url = URL(string: str + imgName)
            do{
                let data = try Data(contentsOf: url!)
                cell.banner_image.image = UIImage(data: data)
            }catch{}
        return cell
        }
        else
        {
            let cell = tableView.dequeueReusableCell(withIdentifier: "cell1", for: indexPath) as! SecondCellForUserHomeSceen
            cell.participant_name.text = discForHomeScreen["pa_name"] as! String
            return cell
        }
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        if indexPath.section == 0 && indexPath.row == 0{
            return 200.0
        }
        else
        {
            return 78.0
        }
    }
    
    var Aodisc :[[String:Any]] = []
    var discForStatus :[String:Any] = [:]
    var AdiscForEvent:[[String:Any]] = []
    var disc1 :[String:Any] = [:]
    var disc2ForEvent:[String:Any] = [:]
    
    func getResponseDataAgain(arrDisc: [[String : Any]]) {
        if arrDisc.count > 0{
            AdiscForEvent = arrDisc
        }
        updating_records()
        tbldatashow.reloadData()
    }
    func Update(str: String) {
        print(str)
    }
    @IBOutlet weak var Segment: UISegmentedControl!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let objClass = dataFetch()
        objClass.delegate = self
        objClass.fetch_data(Filename:"homeFetchUser.php")
        let objFetchAgain = dataFetch()
        objFetchAgain.delegate = self
        objFetchAgain.fetch_data_again(Filename: "votingManageFetchTime.php")
      //  Segment.selectedSegmentIndex = 2
        getLoginData()
        showSegment()
    }
    override func viewWillAppear(_ animated: Bool) {
        Segment.selectedSegmentIndex = 2
        //hidebars()
    }
    
    func hidebars() {
        self.navigationController?.navigationBar.isHidden = true
        self.tabBarController?.tabBar.isHidden = true
    }
    func updating_records() {
        let objUpdate = DataUpdate()
        objUpdate.delegate = self
        for discForUpdatingStatus in AdiscForEvent{
            let StartingTimeForEvent = discForUpdatingStatus["Starting_date"] as! String
            let EndingTimeForEvent = discForUpdatingStatus["Ending_date"] as! String
            let StartingTimeForTimeZone = discForUpdatingStatus["Start_time"] as! String
            let EndingTimeForTimeZone = discForUpdatingStatus["End_time"] as! String
            let Disc = ["Starting_date":StartingTimeForEvent,"Ending_date":EndingTimeForEvent,"Start_time":StartingTimeForTimeZone,"End_time":EndingTimeForTimeZone]
            objUpdate.RecordUpdate(FileName: "eventUpdate.php", DiscData: Disc)
        }
    }
    @IBAction func user_menu(_ sender: Any) {
        let stb = storyboard?.instantiateViewController(withIdentifier: "user_menu") as! user_menu
        self.navigationController?.pushViewController(stb, animated: true)
    }
    func getResponseData(arrDisc: [[String : Any]]) {
        
        if arrDisc.count > 0 {
            Aodisc = arrDisc
            print(Aodisc)
             tbldatashow.reloadData()
        }
       
    }
    func showSegment() {
        if disc1["user_type"] as! String == "Organizer"{
            Segment.isHidden = false
        }
        else{
            Segment.isHidden = true
        }
    }
    
    @IBAction func SegmentChangRole(_ sender: Any) {
        self.navigationController?.navigationBar.isHidden = true
        self.tabBarController?.tabBar.isHidden = true
        if Segment.selectedSegmentIndex == 0 {
            let stb = self.storyboard?.instantiateViewController(withIdentifier: "org_tab")
            self.navigationController?.pushViewController(stb!, animated: true);
        }
        if Segment.selectedSegmentIndex == 1 {
            let stb = self.storyboard?.instantiateViewController(withIdentifier: "participanttab")
            self.navigationController?.pushViewController(stb!, animated: true)
        }
        if Segment.selectedSegmentIndex == 2{
            let stb = self.storyboard?.instantiateViewController(withIdentifier: "Usertab")
            self.navigationController?.pushViewController(stb!, animated: true)
        }
    }
    func getPath() -> String {
        
        let arr = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        let path = arr[0]
        let finalPath = path.appending("/userLogin.plist")
        print(finalPath)
        return finalPath
    }
    func getLoginData() {
        
        let flm = FileManager()
        if flm.fileExists(atPath: getPath()) {
            
            var disc = NSDictionary(contentsOfFile: getPath()) as! [String:Any]
           let  brr = disc["userRecord"] as! [[String:Any]]
            let getDisc = brr[0];
            disc1 = getDisc;
            
        }
    }


}
