//
//  menu.swift
//  screens
//
//  Created by MAC2 on 06/12/18.
//  Copyright © 2018 TOPS. All rights reserved.
//
import SDWebImage
import UIKit

class user_menu: UIViewController,UITableViewDataSource,UITableViewDelegate, UINavigationControllerDelegate{
   
    @IBOutlet weak var userMenu: UITableView!
    
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var img: UIImageView!
    var arrDisc : [[String:Any]] = []
    let brr = ["Profile(participant)","voting zone","event vote","check for upcoming event","result","logout"];
    override func viewDidLoad() {
        super.viewDidLoad()
       // hidebars()
        checkLoginStatus()
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
       return brr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    
            let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
            cell.textLabel?.text = brr[indexPath.row]
            return cell
    }
    override func viewWillAppear(_ animated: Bool) {
//        self.tabBarController?.tabBar.isHidden = true
//        self.navigationController?.navigationBar.isHidden = true
    }
    func getPath() -> String {
        
        let arr = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        let path = arr[0]
        let finalPath = path.appending("/userLogin.plist")
        print(finalPath)
        return finalPath
    }
    func destroyLoginData() {
        
        let flm = FileManager()
        if flm.fileExists(atPath: getPath()) {
            
            var disc = NSDictionary(contentsOfFile: getPath()) as! [String:Any]
            var arr = disc["userRecord"] as! [[String:Any]]
            arr.removeAll()
            disc["userRecord"] = arr
            let finalDisc = NSDictionary(dictionary: disc)
            finalDisc.write(toFile: getPath(), atomically: true)
            
        }
    }
    func checkLoginStatus() {
        
        let flm = FileManager()
        if flm.fileExists(atPath: getPath()) {
            
            var disc = NSDictionary(contentsOfFile: getPath()) as! [String:Any]
            let arr = disc["userRecord"] as! [[String:Any]]
            if arr.count == 1 {
                
            arrDisc = arr
                let getDisc = arrDisc[0]
                let imgData = getDisc["image"] as! String;
                let url = "http://localhost/votingdb/"
                let strUrl = url + imgData
                let finalUrl = URL(string: strUrl)
                do{
                    let imgData = try Data(contentsOf: finalUrl!)
                    img.image = UIImage(data: imgData)
                    img.layer.cornerRadius = img.layer.frame.width / 2
                    img.layer.masksToBounds = true;
                }catch{
                }
                name.text = getDisc["user_fname"] as? String
                //userMenu.reloadData()
            }
        }
    }
    func hidebars()  {
        self.navigationController?.navigationBar.isHidden = true
        self.tabBarController?.tabBar.isHidden = true
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
    if brr[indexPath.row] == "logout" {
          destroyLoginData();
        let stb = self.storyboard?.instantiateViewController(withIdentifier: "login") as! ViewController
            self.navigationController?.pushViewController(stb, animated: true)
        }
        if brr[indexPath.row] == "result" {
            let stb = self.storyboard?.instantiateViewController(withIdentifier: "Result") as! Result
            self.navigationController?.pushViewController(stb, animated: true)
        }
        if brr[indexPath.row] == "voting zone" {
            let stb = self.storyboard?.instantiateViewController(withIdentifier: "time_zone") as! time_zone
            self.navigationController?.pushViewController(stb, animated: true)
        }
        if brr[indexPath.row] == "Profile(participant)"
        {
            let stb = self.storyboard?.instantiateViewController(withIdentifier: "show_participants") as! show_participants
            self.navigationController?.pushViewController(stb, animated: true)
        }
        if brr[indexPath.row] == "event vote"{
            let stb = self.storyboard?.instantiateViewController(withIdentifier: "event") as! event
            self.present(stb, animated: true, completion: nil)
        }
        if brr[indexPath.row] == "check for upcoming event"
        {
            let stb = self.storyboard?.instantiateViewController(withIdentifier: "CheckForUpcomingEvent") as! CheckForUpcomingEvent
            self.navigationController?.pushViewController(stb, animated: true)
        }
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
            return 50.0
        }
    @IBAction func edt_profile(_ sender: Any) {
        moveScreens()
    }
    func moveScreens() {
        let stb = self.storyboard?.instantiateViewController(withIdentifier: "profile_user") as! profile_user
        self.navigationController?.pushViewController(stb, animated: true)
    }
}
