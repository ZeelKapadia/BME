//
//  Participants.swift
//  screens
//
//  Created by MAC2 on 08/12/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

class Participants: UIViewController , FetchDelegate,UITableViewDelegate,UITableViewDataSource{

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return aoDisc.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let disc = aoDisc[indexPath.row]
        var name :String = ""
        if disc["user_type"] as! String == "Participant"{
        let fname = disc["user_fname"] as! String
        let lname = disc["user_lname"] as! String
        name = fname + lname
        }
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        cell.textLabel?.text = name
        return cell
    }
    
    func getResponseData(arrDisc: [[String : Any]]) {
        if arrDisc.count > 0 {
        aoDisc = arrDisc
        }
        tblrdata.reloadData()
    }
    
    func getResponseDataAgain(arrDisc: [[String : Any]]) {
        
    }
    
    @IBOutlet weak var tblrdata: UITableView!
    
    var aoDisc : [[String:Any]] = []
  
    override func viewDidLoad() {
        super.viewDidLoad()
        fetch()
       
    }
    func fetch() {
        let objClass = dataFetch()
        objClass.delegate = self
        objClass.fetch_data(Filename: "UserFetch.php")
    }

 
}
