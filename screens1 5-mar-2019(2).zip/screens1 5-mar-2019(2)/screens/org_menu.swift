import UIKit
import SDWebImage

class org_menu: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    @IBOutlet weak var img: UIImageView!
    @IBOutlet weak var name: UILabel!
    
let arr = ["Create Event","Show My Events","Result","Logout"]
    override func viewDidLoad() {
        super.viewDidLoad()
      //  hidebars()
    checkLoginStatus()
    }
    func hidebars()  {
        self.navigationController?.navigationBar.isHidden = true
        self.tabBarController?.tabBar.isHidden = true
    }
    func getPath() -> String {
        
        let arr = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        let path = arr[0]
        let finalPath = path.appending("/userLogin.plist")
        print(finalPath)
        return finalPath
    }
    func destroyLoginData() {
        
        let flm = FileManager()
        if flm.fileExists(atPath: getPath()) {
            
            var disc = NSDictionary(contentsOfFile: getPath()) as! [String:Any]
            var arr = disc["userRecord"] as! [[String:Any]]
            arr.removeAll()
            disc["userRecord"] = arr
            let finalDisc = NSDictionary(dictionary: disc)
            finalDisc.write(toFile: getPath(), atomically: true)
            
        }
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arr.count;
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        cell.textLabel?.text = arr[indexPath.row];
        return cell;
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print(arr[indexPath.row]);
        if arr[indexPath.row] == "Logout"{
            destroyLoginData()
            let stb = self.storyboard?.instantiateViewController(withIdentifier: "login") as! ViewController;
            self.navigationController?.pushViewController(stb, animated: true);
        }
        if arr[indexPath.row] == "Create Event"{
            let stb = self.storyboard?.instantiateViewController(withIdentifier: "create_event") as! create_event;
            self.navigationController?.pushViewController(stb, animated: true);
            }
        if arr[indexPath.row] == "Users"{
            let stb = self.storyboard?.instantiateViewController(withIdentifier: "show_user") as! show_user;
            self.navigationController?.pushViewController(stb, animated: true);        }
        /*if arr[indexPath.row] == "Participant"{
            let stb = self.storyboard?.instantiateViewController(withIdentifier: "") as! ;
            self.navigationController?.pushViewController(stb, animated: true);
        }*/
        if arr[indexPath.row] == "allow" {
            let stb = self.storyboard?.instantiateViewController(withIdentifier: "allow") as! allow
            self.navigationController?.pushViewController(stb, animated: true)
        }
        if arr[indexPath.row] == "Result"{
            let stb = self.storyboard?.instantiateViewController(withIdentifier: "Result") as! Result;
            self.navigationController?.pushViewController(stb, animated: true);
        }
        if arr[indexPath.row] == "Show My Events"{
            let stb = self.storyboard?.instantiateViewController(withIdentifier: "org_events") as! org_events;
            self.navigationController?.pushViewController(stb, animated: true);
    }
 
}
    func checkLoginStatus() {
        
        let flm = FileManager()
        if flm.fileExists(atPath: getPath()) {
            
            var disc = NSDictionary(contentsOfFile: getPath()) as! [String:Any]
            let arr = disc["userRecord"] as! [[String:Any]]
            if arr.count == 1 {
                
                let getDisc = arr[0]
                let imgData = getDisc["image"] as! String;
                let url = "http://localhost/votingdb/"
                let strUrl = url + imgData
                let finalUrl = URL(string: strUrl)
                do{
                    let imgData = try Data(contentsOf: finalUrl!)
                    img.image = UIImage(data: imgData)
                    img.layer.cornerRadius = img.layer.frame.width / 2
                    img.layer.masksToBounds = true;
                }catch{
                }
                name.text = getDisc["user_fname"] as? String
                //userMenu.reloadData()
            }
        }
    }
    @IBAction func btn_update_profile(_ sender: Any) {
       let stb = self.storyboard?.instantiateViewController(withIdentifier: "profile_user") as! profile_user
        self.navigationController?.pushViewController(stb, animated: true)
    }
}
