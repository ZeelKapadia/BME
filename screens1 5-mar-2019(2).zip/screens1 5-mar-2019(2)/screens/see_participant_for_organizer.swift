//participants that apply for the event

import UIKit

class see_participant_for_organizer: UIViewController,UITableViewDelegate,UITableViewDataSource,FetchDelegate {
   
    var arrEvent : [[String:Any]] = []
    var disc : [String:Any] = [:]

    override func viewDidLoad() {
        super.viewDidLoad()
        getdata()
        hidebars()
    }
    func hidebars() {
        self.navigationController?.navigationBar.isHidden = true
        self.tabBarController?.tabBar.isHidden = true
    }
    func getdata() {
        let objClassEvent = dataFetch()
        objClassEvent.delegate = self
        objClassEvent.fetch_data(Filename: "eventFetchMulTable.php")
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrEvent.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        disc = arrEvent[indexPath.row]
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        let fname = disc["user_fname"] as? String
        let lname = disc["user_lname"] as? String
        let name = fname! + lname!
        cell.textLabel?.text = disc["E_name"] as? String
        cell.detailTextLabel?.text = name
        return cell
    }
    func getResponseData(arrDisc: [[String : Any]]) {
        arrEvent = arrDisc
    }
    
    func getResponseDataAgain(arrDisc: [[String : Any]]) {
        
    }

}
