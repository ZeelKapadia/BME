import AVFoundation
import AVKit
import UIKit
import SDWebImage

class participant: UIViewController,UITableViewDataSource,UITableViewDelegate,FetchDelegate{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrPost.count
    }
    
    override func viewWillAppear(_ animated: Bool) {
        SegmentChangedState.selectedSegmentIndex = 1
        //self.navigationController?.navigationBar.isHidden = true
       // self.tabBarController?.tabBar.isHidden = true
    }
    func hidebars() {
//        self.navigationController?.navigationBar.isHidden = true
//        self.tabBarController?.tabBar.isHidden = true
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        discForData = arrPost[indexPath.row]
        let idFromSimu = DiscForId["user_id"] as! String
        let idFromData = discForData["pa_id"] as! String
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! CustCellForParticipant
        if idFromSimu == idFromData{
        let type = discForData["Post_type"] as! String
    if type == "Image" {
        let imgName = discForData["Image_data"] as! String
        let url = "http://localhost/votingdb/"
        let strUrl = url + imgName
        let finalUrl = URL(string: strUrl)
        do{
            let imgData = try Data(contentsOf: finalUrl!)
            cell.btnPlay.isHidden = true
            cell.imgvideo.image = UIImage(data: imgData)
        }catch{}
        }
    else if type == "Video"{
        let temp = arrPost[indexPath.row] as! [String:String]
        let str = "http://localhost/votingdb/"
        let videoPath = temp["video_data"]
        let fullPath = str.appending(videoPath!)
        print(fullPath)
        let url = URL(string: fullPath)
        let img = getThumbnailImage(forUrl: url!)
        cell.imgvideo.image = img
        TempDisc = temp
        cell.btnPlay.isHidden = false
        cell.btnPlay.addTarget(self, action: #selector(self.play), for: .touchUpInside)
            }
        }
        return cell
    }
    
 
    @IBOutlet weak var menu: UIBarButtonItem!
    @IBOutlet weak var img: UIImageView!
    @IBOutlet weak var SegmentChangedState: UISegmentedControl!
  
    var DiscForId : [String:Any] = [:]
    var arrPost : [[String:Any]] = []
    var discForData : [String:Any] = [:]
    var TempDisc : [String:String] = [:]

    @IBOutlet weak var tblhome: UITableView!
    override func viewDidLoad() {
        checkLoginStatus()
       showSegment()
        fetch()
        SegmentChangedState.selectedSegmentIndex = 1
    }
    func fetch() {
        let objClass = dataFetch()
        objClass.delegate = self
        objClass.fetch_data(Filename: "UploadFetch.php")
    }
    func getResponseData(arrDisc: [[String : Any]]) {
        if arrDisc.count > 0 {
            print(arrDisc)
            arrPost = arrDisc
        }
        tblhome.reloadData()
    }
    
    func getResponseDataAgain(arrDisc: [[String : Any]]) {
        
    }
    
    func showSegment()  {
        if DiscForId["user_type"] as! String == "Organizer"{
            SegmentChangedState.isHidden = false
        }
        else{
            SegmentChangedState.isHidden = true
        }
    }
    
    @IBAction func SegmentRoles(_ sender: Any) {
        self.navigationController?.navigationBar.isHidden = true
        self.tabBarController?.tabBar.isHidden = true
        if SegmentChangedState.selectedSegmentIndex == 0 {
            let stb = self.storyboard?.instantiateViewController(withIdentifier: "org_tab")
            self.navigationController?.pushViewController(stb!, animated: true);
        }
        if SegmentChangedState.selectedSegmentIndex == 1 {
            let stb = self.storyboard?.instantiateViewController(withIdentifier: "participanttab")
            self.navigationController?.pushViewController(stb!, animated: true)
        }
        if SegmentChangedState.selectedSegmentIndex == 2 {
            let stb = storyboard?.instantiateViewController(withIdentifier: "Usertab")
            self.navigationController?.pushViewController(stb!, animated: true)
        }
    }
    @IBAction func participant_menu(_ sender: Any) {
        let stb = self.storyboard?.instantiateViewController(withIdentifier: "participant_menu") as! participant_menu;
        self.navigationController? .pushViewController(stb, animated: true)
    }
    func play() {
        let str = "http://localhost/votingdb/"
        let videoPath = TempDisc["video_data"]
        let fullPath = str.appending(videoPath!)
        print(fullPath)
        let videoURL = URL(string: fullPath)
        let player = AVPlayer(url: videoURL!)
        let playerViewController = AVPlayerViewController()
        playerViewController.player = player
        self.present(playerViewController, animated: true) {
            playerViewController.player!.play()
        }
    }
    func getThumbnailImage(forUrl url: URL) -> UIImage? {
        let asset: AVAsset = AVAsset(url: url)
        let imageGenerator = AVAssetImageGenerator(asset: asset)
        
        do {
            let thumbnailImage = try imageGenerator.copyCGImage(at: CMTimeMake(1, 60) , actualTime: nil)
            return UIImage(cgImage: thumbnailImage)
        } catch let error {
            print(error)
        }
        return nil
    }
    func getPath() -> String {
        
        let arr = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        let path = arr[0]
        let finalPath = path.appending("/userLogin.plist")
        print(finalPath)
        return finalPath
    }
    func checkLoginStatus() {
        
        let flm = FileManager()
        if flm.fileExists(atPath: getPath()) {
            
            var disc = NSDictionary(contentsOfFile: getPath()) as! [String:Any]
            let arr = disc["userRecord"] as! [[String:Any]]
            if arr.count == 1 {
                DiscForId = arr[0]
                print(DiscForId)
            }
        }
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 250.0
    }
}
