//
//  allow.swift
//  screens
//
//  Created by Zeel Kapadia on 07/02/19.
//  Copyright © 2019 TOPS. All rights reserved.
//
import SDWebImage

import UIKit
import AVFoundation
import AVKit

class allow: UIViewController,UITableViewDataSource,UITableViewDelegate,FetchDelegate {
    func getResponseData(arrDisc: [[String : Any]]) {
        if arrDisc.count > 0 {
            arrForVotes = arrDisc
        }
        tblshowdata.reloadData()
    }
    
    func getResponseDataAgain(arrDisc: [[String : Any]]) {
        }
    
    
    @IBOutlet weak var tblshowdata: UITableView!
    var arrForVotes:[[String:Any]] = []
    var dics :[String:Any] = [:]
    var TempDisc : [String:String] = [:]
    var strOfName = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        objCreate()
    }
    func objCreate()  {
        let objClass = dataFetch()
        objClass.delegate = self
        objClass.fetch_data(Filename: "UploadFetch.php")
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrForVotes.count;
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! CustcellForOrganizer
        dics = arrForVotes[indexPath.row]
        let fname : String = dics["user_fname"] as! String
        let lname : String = dics["user_lname"] as! String
        strOfName = fname + lname
        // print(str);
        
        let post_type = dics["Post_type"] as! String
        if post_type == "Image"
        {
            let imgName = dics["Image_data"] as! String
            let url = "http://localhost/votingdb/"
            let strUrl = url + imgName
            let finalUrl = URL(string: strUrl)
            do{
                let imgData = try Data(contentsOf: finalUrl!)
                cell.btnPlay.isHidden = true
                cell.img.image = UIImage(data: imgData)
                cell.lbl_eventName.text = strOfName
            }catch{}
            return cell
        }
        if post_type == "Video"
        {
            let temp = arrForVotes[indexPath.row] as! [String:String]
            let str = "http://localhost/votingdb/"
            let videoPath = temp["video_data"]
            let fullPath = str.appending(videoPath!)
            print(fullPath)
            let url = URL(string: fullPath)
            let img = getThumbnailImage(forUrl: url!)
            cell.imageView?.image = img
            TempDisc = temp
            cell.btnPlay.isHidden = false
            cell.btnPlay.addTarget(self, action: #selector(self.play), for: .touchUpInside)
            
            cell.lbl_eventName.text = strOfName
            return cell
        }
        else{
            return cell
        }
    }
    func play() {
        let str = "http://localhost/votingdb/"
        let videoPath = TempDisc["video_data"]
        let fullPath = str.appending(videoPath!)
        print(fullPath)
        let videoURL = URL(string: fullPath)
        let player = AVPlayer(url: videoURL!)
        let playerViewController = AVPlayerViewController()
        playerViewController.player = player
        self.present(playerViewController, animated: true) {
            playerViewController.player!.play()
        }
    }
    func getThumbnailImage(forUrl url: URL) -> UIImage? {
        let asset: AVAsset = AVAsset(url: url)
        let imageGenerator = AVAssetImageGenerator(asset: asset)
        
        do {
            let thumbnailImage = try imageGenerator.copyCGImage(at: CMTimeMake(1, 60) , actualTime: nil)
            return UIImage(cgImage: thumbnailImage)
        } catch let error {
            print(error)
        }
        
        return nil
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 415.0
    }

    @IBAction func home(_ sender: Any) {
        moveHome()
    }
    func moveHome() {
        let stb = self.storyboard?.instantiateViewController(withIdentifier: "org_tab")
        self.navigationController?.pushViewController(stb!, animated: true)
    }

}
