//
//  change_password.swift
//  screens
//
//  Created by Zeel Kapadia on 24/01/19.
//  Copyright © 2019 TOPS. All rights reserved.
//

import UIKit

class change_password: UIViewController,DataUpdatedDelegate {
    func Update(str: String) {
        print(str);
        if str == "Success" {
            alert()
        }
    }
    
    func UpdateAgain(str: String) {
        
    }
    

    @IBOutlet weak var btncp: UIButton!
    @IBOutlet weak var txtPassword: UITextField!
    @IBOutlet weak var txtPasswordAg: UITextField!
    
    var u_email = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()

        btncp.layer.cornerRadius = btncp.layer.frame.height / 2;
        btncp.clipsToBounds = true
       
        // Do any additional setup after loading the view.
    }
    
    @IBAction func changing_password(_ sender: Any) {
        check()
    }
    func check() {
        if txtPassword.text == "" || txtPasswordAg.text == "" {
                let alt = UIAlertController(title: "Empty Field Found", message: "please enter your password twice", preferredStyle: .actionSheet)
                let ok = UIAlertAction(title: "OK", style: .default, handler: nil)
            alt.addAction(ok)
            self.present(alt, animated: true
                , completion: nil)
        }
        else {
            if txtPassword.text == txtPasswordAg.text {
                update()
            }
            else{
                let alt = UIAlertController(title: "Strings not match", message: "please enter the valid data", preferredStyle: .alert)
                let ok = UIAlertAction(title: "OK", style: .default, handler: nil)
                alt.addAction(ok)
                self.present(alt, animated: true, completion: nil)
            }
        }
    }
    func alert() {
        let alt = UIAlertController(title: "Confirm", message: "DO you really want to reset your password??", preferredStyle: .alert)
        let ok = UIAlertAction(title: "OK", style: .default, handler: ({action in
            self.move_to_first_page()
        }))
        let cancel = UIAlertAction(title: "Cancel", style: .destructive, handler: nil)
        alt.addAction(ok);
        alt.addAction(cancel);
    }
    func move_to_first_page() {
        let stb = self.storyboard?.instantiateViewController(withIdentifier: "login")
        self.navigationController?.pushViewController(stb!, animated: true)
    }
    func update() {
        let objClass = DataUpdate()
        objClass.delegate = self
        let disc = ["user_email":u_email , "password":txtPassword.text!]
        objClass.RecordUpdate(FileName: "Change.php", DiscData: disc)
    }
}
