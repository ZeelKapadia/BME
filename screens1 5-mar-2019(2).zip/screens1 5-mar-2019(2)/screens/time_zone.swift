import UIKit
import SDWebImage


class time_zone: UIViewController,FetchDelegate,UITableViewDataSource,UITableViewDelegate,DataUpdatedDelegate {
    func Update(str: String) {
        print(str)
    }
    
    func UpdateAgain(str: String) {
        
    }
    
   
    var AoDiscForStatus:[[String:Any]] = []
    var DiscForStatus :[String:Any] = [:]
    var DiscforId : [String:Any] = [:]
    
    @IBOutlet weak var tbleventcheckin: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //hidebars()
        insertLoginData()
        getdates()
       }
    func getPath() -> String {
        
        let arr = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        let path = arr[0]
        let finalPath = path.appending("/userLogin.plist")
        print(finalPath)
        return finalPath
    }
    func insertLoginData() {
        
        let flm = FileManager()
        if flm.fileExists(atPath: getPath()) {
            
            var disc = NSDictionary(contentsOfFile: getPath()) as! [String:Any]
            var arr = disc["userRecord"] as! [[String:Any]]
            DiscforId = arr[0];
            
        }
    }
    func hidebars() {
        self.navigationController?.navigationBar.isHidden = true
        self.tabBarController?.tabBar.isHidden = true
    }

    func getdates() {
        let objClass = dataFetch();
        objClass.delegate = self
        objClass.fetch_data(Filename: "votingManageFetchTime.php")
    }
    func getResponseData(arrDisc: [[String : Any]]) {
        if arrDisc.count > 0 {
            AoDiscForStatus = arrDisc
        }
        tbleventcheckin.reloadData()
    }
    func getResponseDataAgain(arrDisc: [[String : Any]]) {
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return AoDiscForStatus.count;
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1;
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! CustomCellForTimeZone
        cell.btn_check_in.tag = indexPath.row
        DiscForStatus = AoDiscForStatus[indexPath.row]
//        let curdate = Date()
//        let SD = DiscForStatus["Start_time"] as! String
//        let ED = DiscForStatus["End_time"] as! String
//        let frm = DateFormatter()
//        frm.dateFormat = "yyyy-MM-dd HH:mm:SS"
//        let end_time = frm.date(from: ED)
//        let start_time = frm.date(from: SD)
//        frm.dateFormat = "yyyy-MM-dd"
//        let SdateStr = frm.string(from: start_time!)
//        let EdateStr = frm.string(from: end_time!)
//        let curStr = frm.string(from: curdate)
//        let dat = frm.date(from: curStr)
//        let SDate = frm.date(from: SdateStr)
//        let EDate = frm.date(from: EdateStr)
//        frm.dateFormat = "HH"
//        let HStr = frm.string(from: curdate)
//        let SHS = frm.string(from: start_time!)
//        let EHS = frm.string(from: end_time!)
//        let H = frm.date(from: HStr)
//        let SH = frm.date(from: SHS)
//        let EH = frm.date(from: EHS)
//        frm.dateFormat = "mm"
//        let MSS = frm.string(from: start_time!)
//        let MES = frm.string(from: end_time!)
//        let Mstr = frm.string(from: curdate)
//        let M = frm.date(from: Mstr)
//        let SM = frm.date(from: MSS)
//        let EM = frm.date(from: MES)
//        frm.dateFormat = "SS"
//        let SecStr = frm.string(from: curdate)
//        let SSecS = frm.string(from: start_time!)
//        let ESecS = frm.string(from: end_time!)
//        let Sec = frm.date(from: SecStr)
//        let SSec = frm.date(from: SSecS)
//        let ESec = frm.date(from: ESecS)
//
//        if EdateStr >= curStr {
//            let End = (EdateStr as NSString).integerValue
//            let cure = (SdateStr as NSString).integerValue
//            let diff = End - cure
//        }
        
        let imgData = DiscForStatus["Banner_image"] as! String;
        let url = "http://localhost/votingdb/"
        let strUrl = url + imgData
        let finalUrl = URL(string: strUrl)
        do{
            let imgData = try Data(contentsOf: finalUrl!)
            cell.imgForEvent.image = UIImage(data: imgData)
        }catch{
        }
        cell.lbl_event_name.text = DiscForStatus["E_name"] as? String
        let V_St = DiscForStatus["V_Status"] as! String
        cell.Status.text = V_St

        if (DiscForStatus["V_Status"] as? String) == "Complete"
        {
            //cell.btn_check_in.setTitle("Result", for: .normal)
            cell.btn_check_in.addTarget(self, action: #selector(self.checkin), for: .touchUpInside)
        }
        if (DiscForStatus["V_Status"]as? String) == "Running"
        {
            cell.btn_check_in.addTarget(self, action: #selector(self.checkin), for: .touchUpInside)
        }
        if (DiscForStatus["V_Status"]as? String) == "Upcoming"
        {
            cell.btn_check_in.isHidden = true
        }
        else if (DiscForStatus["V_Status"]as? String) == "" {
            let alt = UIAlertController(title: "Details not found", message: "There is not a such videos for you", preferredStyle: .alert)
            let ok = UIAlertAction(title: "OK", style: .default, handler: nil)
            alt.addAction(ok)
            self.present(alt, animated: true, completion: nil)
        }
      //  cell.Status.text = DiscForStatus["V_Status"] as! String
       return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 310.0
    }
    /*func result() {
        let stb = storyboard?.instantiateViewController(withIdentifier: "Result") as! Result
        self.navigationController?.pushViewController(stb, animated: true)
    }*/
    func checkin(sender : UIButton) {
        let stb = storyboard?.instantiateViewController(withIdentifier: "GiveYourVotes") as! GiveYourVotes
        stb.V_Status = DiscForStatus["V_Status"] as! String
        stb.eid = DiscForStatus["E_id"] as! String
         
        stb.O_id = DiscForStatus["O_id"] as! String
        stb.Vm_id = DiscForStatus["Vm_id"] as! String
        self.navigationController?.pushViewController(stb, animated: true)
    }
  
}
