import UIKit
import SDWebImage

class profile_user : UIViewController,UIImagePickerControllerDelegate,UINavigationControllerDelegate {
    
    

    @IBOutlet weak var txtlname: UITextField!
    @IBOutlet weak var txtfname: UITextField!
    @IBOutlet weak var img: UIImageView!
    @IBOutlet weak var txtemail: UITextField!
    var brr : [String:Any] = [:]
    
    var updatedData : [[String:Any]] = []
  
    @IBOutlet weak var btnEP: UIButton!
    @IBOutlet weak var btnSubmit: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        img.layer.cornerRadius = img.layer.frame.size.width  / 2;
        img.clipsToBounds = true;
        getLoginData()
        showdata()
       
        btnEP.layer.cornerRadius = btnEP.layer.frame.height / 2;
        btnEP.clipsToBounds = true
        
        btnSubmit.layer.cornerRadius = btnSubmit.layer.frame.height / 2;
        btnSubmit.clipsToBounds = true
    }
    func hidebars() {
        self.navigationController?.navigationBar.isHidden = true
        self.tabBarController?.tabBar.isHidden = true
    }
    func getPath() -> String {
        let arr = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        let path = arr[0]
        let finalPath = path.appending("/userLogin.plist")
        print(finalPath)
        return finalPath
    }
    func getLoginData() {
        
        let flm = FileManager()
        if flm.fileExists(atPath: getPath()) {
            
            var disc = NSDictionary(contentsOfFile: getPath()) as! [String:Any]
            let arr = disc["userRecord"] as! [[String:Any]]
            brr = arr[0] ;
        }
    }
    func showdata() {
        txtfname.text = brr["user_fname"] as? String;
        txtlname.text = brr["user_lname"] as? String;
        txtemail.text = brr["user_email"] as? String;
        let imgData = brr["image"] as! String;
        let url = "http://localhost/votingdb/"
        let strUrl = url + imgData
        let finalUrl = URL(string: strUrl)
        do{
            let imgData = try Data(contentsOf: finalUrl!)
            img.image = UIImage(data: imgData)
        }catch{
        }
    }
    @IBAction func btnpicture(_ sender: Any) {
        alert()
    }
    func alert() {
        let alt = UIAlertController(title: "Add your profile", message: "Select any option", preferredStyle: .alert)
        let camera = UIAlertAction(title: "Camera", style: .default, handler: {action in
            let picker = UIImagePickerController()
            picker.sourceType = .camera
            picker.delegate = self;
            self.present(picker,animated: true,completion: nil)
        })
        let gallery = UIAlertAction(title: "Gallery", style: .default, handler: {action in
            let picker = UIImagePickerController()
            picker.sourceType = .photoLibrary
            picker.delegate = self;
            self.present(picker,animated: true,completion: nil)
        })
        alt.addAction(camera);
        alt.addAction(gallery);
        
        
        self.present(alt, animated: true, completion: nil)
        }
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        let img1 = info[UIImagePickerControllerOriginalImage] as! UIImage;
        img.image = img1;
        self.dismiss(animated: true, completion: nil);
        
    }
    @IBAction func btn_updateaction(_ sender: Any) {
        
        updateUser()
  
    }
    //for moving the particular tabs
    func move() {
        let type = brr["user_type"] as! String
        if type == "Organizer"
        {
            let stb = self.storyboard?.instantiateViewController(withIdentifier: "org_tab")
            self.navigationController?.pushViewController(stb!, animated: true)
        }
        else if type == "Participant"{
            let stb = self.storyboard?.instantiateViewController(withIdentifier: "participanttab")
            self.navigationController?.pushViewController(stb!, animated: true)
        }
        else if type == "User"{
            let stb = self.storyboard?.instantiateViewController(withIdentifier: "Usertab")
            self.navigationController?.pushViewController(stb!, animated: true)
        }
    }
    func updateUser()  {
        let imgData = UIImagePNGRepresentation(img.image!)
        let baseStr = imgData?.base64EncodedString(options: Data.Base64EncodingOptions.lineLength64Characters)
        
        let str = "http://localhost/votingdb/UserUpdateProfile.php"
        let disc : [String : Any] = ["user_id":brr["user_id"]!,"user_fname":txtfname.text!,"user_lname":txtlname.text!,"user_email":txtemail.text!,"image":baseStr!]
        do {
            
            let body = try JSONSerialization.data(withJSONObject: disc, options: [])
            let url = URL(string: str)
            var request = URLRequest(url: url!)
            
            request.addValue(String(body.count), forHTTPHeaderField: "Content-Length")
            request.httpBody = body
            request.httpMethod = "POST"
            
            let session = URLSession.shared
            let datatask = session.dataTask(with: request){ (data1, resp, err) in
                
                let result = String(data: data1!, encoding: String.Encoding.utf8)
                print(result!)
                do{
                    let jsonData = try JSONSerialization.jsonObject(with: data1!, options: []) as! [[String:Any]]
                    self.updatedData = jsonData
                    DispatchQueue.main.async {
                        
                        if jsonData.count == 1
                        {
                            self.updateplist()
                            let alt = UIAlertController(title: "Alert message", message: "your information is updated Successfully", preferredStyle: .alert)
                            
                            let ok1 = UIAlertAction(title: "OK", style: .default, handler: { (dt) in
                                self.move()
                              //  let st = self.navigationController?.popToRootViewController(animated: true);
                              //  print(st!);
                            })
                            alt.addAction(ok1);
                            self.present(alt, animated: true, completion:nil)
                        }
                        else
                        {
                            let alt = UIAlertController(title: "Confirmation", message: "your record not updated", preferredStyle: .alert)
                            let ok1 = UIAlertAction(title: "OK", style: .default, handler: { (dt) in
                                self.move()
                              //  let st = self.navigationController?.popToRootViewController(animated: true)
                                //print(st!)
                            })
                            alt.addAction(ok1);
                            self.present(alt, animated: true, completion:nil)
                        }
                    }
                }catch{
                }
            }
            datatask.resume()
        }catch  {
        }
    }
    func updateplist() {
        let flm = FileManager()
        if flm.fileExists(atPath: getPath()) {
            
            var disc = NSDictionary(contentsOfFile: getPath()) as! [String:Any]
            var arr = disc["userRecord"] as! [[String:Any]]
            arr = updatedData;
            disc["userRecord"] = arr
            let finalDisc = NSDictionary(dictionary: disc)
            finalDisc.write(toFile: getPath(), atomically: true)
        }
    }
}
