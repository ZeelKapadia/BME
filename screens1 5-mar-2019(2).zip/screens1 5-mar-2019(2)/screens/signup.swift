import SDWebImage
import UIKit

class signup: UIViewController,UITableViewDataSource,UITableViewDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate{

    var type  = "";
    @IBOutlet weak var img: UIImageView!
    @IBOutlet weak var txtpassword: UITextField!
    @IBOutlet weak var instruction: UILabel!
    @IBOutlet weak var fname: UITextField!
    @IBOutlet weak var lname: UITextField!
    @IBOutlet weak var email: UITextField!
    @IBOutlet weak var tblViewUserType: UITableView!
    @IBOutlet weak var btnSignin: UIButton!
    @IBOutlet weak var btnLogin: UIButton!
    
    @IBOutlet weak var show: UIButton!
    var arr : [String] = ["User","Participant","Organizer"];
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        btnLogin.layer.cornerRadius = btnLogin.layer.frame.height / 2;
        btnLogin.clipsToBounds = true
        btnSignin.layer.cornerRadius = btnSignin.layer.frame.height / 2;
        btnSignin.clipsToBounds = true
        fname.placeholder = "enter your first name";
        lname.placeholder = "enter your last name";
        email.placeholder = "enter your email.";
        txtpassword.placeholder = "enter your password";
        
        instruction.isHidden = true
        
        img.layer.cornerRadius = img.layer.frame.width / 2 ;
        img.clipsToBounds = true;
        //show.titleLabel?.text = "show"
    }
    @IBAction func btnlogin(_ sender: Any) {
        let stb = storyboard?.instantiateViewController(withIdentifier: "login") as! ViewController;
        self.navigationController?.pushViewController(stb, animated: true)
    }
    @IBAction func add_picture(_ sender: Any) {
        let alt = UIAlertController(title: "Add your profile", message: "Select any option", preferredStyle: .alert)
        let camera = UIAlertAction(title: "Camera", style: .default, handler: {action in
            let picker = UIImagePickerController()
            picker.sourceType = .camera
            picker.delegate = self;
            self.present(picker,animated: true,completion: nil)
        })
        let gallery = UIAlertAction(title: "Gallery", style: .default, handler: {action in
            let picker = UIImagePickerController()
            picker.sourceType = .photoLibrary
            picker.delegate = self;
            self.present(picker,animated: true,completion: nil)
        })
        alt.addAction(camera);
        alt.addAction(gallery);
        
        
        self.present(alt, animated: true, completion: nil)
    }
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        let img1 = info[UIImagePickerControllerOriginalImage] as! UIImage;
        img.image = img1;
        
        self.dismiss(animated: true, completion: nil);
        
    }
   
    
    @IBAction func btnshow(_ sender: Any) {
        show.titleLabel?.text = "show"
        if show.titleLabel?.text == "show"  {
            
            show.setTitle("hide", for: .normal)
            txtpassword.isSecureTextEntry = false
         //   show.titleLabel?.text = "hide"
        //    show.setImage(UIImage(named: "eye.png"), for: .normal)
        }
        else if show.titleLabel?.text == "hide" {
            txtpassword.isSecureTextEntry = true
           show.setTitle("show", for: .normal)
       //     show.titleLabel!.text = "show"
            //show.setImage(UIImage(named:  "hidden eye.png"), for: .normal)
        }
    }
    
    @IBAction func edtpasend(_ sender: Any) {
        instruction.isHidden = true
    }

    @IBAction func emailvalidation(_ sender: UITextField) {
        instruction.isHidden = false
        if isValidEmail(email: email.text!) {
            
            email.rightViewMode = .never
            email.clipsToBounds = true
            email.layer.borderWidth = 1
            email.layer.borderColor = UIColor.green.cgColor
        }
        else {
            
            email.layer.borderWidth = 1
            email.layer.borderColor = UIColor.red.cgColor
        }
        instruction.text = "Enter in this format : Firstpart@secondPart.domainname"
        
    }
    
    @IBAction func ending(_ sender: Any) {
        
        instruction.isHidden = true
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return arr.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        cell.textLabel?.text = arr[indexPath.row]
        return cell;
    }
   func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    
    type = arr[indexPath.row];
    
    print(arr[indexPath.row])
    }
    
    func tableView(_ tableView: UITableView, accessoryButtonTappedForRowWith indexPath: IndexPath) {
        print([indexPath.row])
    }
    
    
    @IBAction func btnreg(_ sender: Any) {
        instruction.isHidden = true

        if fname.text != "" && lname.text != "" && email.text != "" && txtpassword.text != "" && type != "" && img.image != nil {
            if fname.text != "" {
                if lname.text != "" {
                    if img.image != nil{
                
           if isValidEmail(email: email.text!) {
                
              if isValidPassword(pwd: txtpassword.text!){
                    
                    insertUser()
                }
                else{
                let alt = UIAlertController(title: "Empty field found", message: "enter your password properly", preferredStyle: .alert)
                
                let ok1 = UIAlertAction(title: "OK", style: .default, handler: { (dt) in
                    
                            })
                alt.addAction(ok1);
                self.present(alt, animated: true, completion:nil)
                    print("enter valid password")
                }
            }else{
            let alt = UIAlertController(title: "Empty field found", message: "enter your Email id properly", preferredStyle: .alert)
            
            let ok1 = UIAlertAction(title: "OK", style: .default, handler: { (dt) in
                
            })
            alt.addAction(ok1);
            self.present(alt, animated: true, completion:nil)
                print("enter valid email")
            }
        }
            }else{
                let alt = UIAlertController(title: "do you really want to not set your profile ?", message: "select your image", preferredStyle: .alert)
                
                let ok1 = UIAlertAction(title: "OK", style: .default, handler: { (dt) in
                    
                })
                alt.addAction(ok1);
                self.present(alt, animated: true, completion:nil)
                print("enter fully detail")
            }
        }else{
    let alt = UIAlertController(title: "Empty field found", message: "enter your last name", preferredStyle: .alert)
    
    let ok1 = UIAlertAction(title: "OK", style: .default, handler: { (dt) in
    
    })
    alt.addAction(ok1);
    self.present(alt, animated: true, completion:nil)
    print("enter fully detail")
    }
    }else{
            let alt = UIAlertController(title: "Empty field found", message: "enter your first name", preferredStyle: .alert)
            
            let ok1 = UIAlertAction(title: "OK", style: .default, handler: { (dt) in
                
            })
            alt.addAction(ok1);
            self.present(alt, animated: true, completion:nil)
            print("enter fully detail")
        }
    }
    func insertUser()  {
        let imgData = UIImagePNGRepresentation(img.image!)
        let baseStr = imgData?.base64EncodedString(options: Data.Base64EncodingOptions.lineLength64Characters)
        let str = "http://localhost/votingdb/UserRegistration.php"
        let disc : [String : Any] = ["user_fname":fname.text!,"user_lname":lname.text!,"user_email":email.text!,"user_password":txtpassword.text!,"user_type":type,"image":baseStr!]
        
        do {
            
            let body = try JSONSerialization.data(withJSONObject: disc, options: [])
            let url = URL(string: str)
            var request = URLRequest(url: url!)
            
            request.addValue(String(body.count), forHTTPHeaderField: "Content-Length")
            request.httpBody = body
            request.httpMethod = "POST"
            
            let session = URLSession.shared
            let datatask = session.dataTask(with: request){ (data1, resp, err) in
                
                let result = String(data: data1!, encoding: String.Encoding.utf8)
                print(result!)
                DispatchQueue.main.async {
                    
                    if result == "success"
                    {
                        let alt = UIAlertController(title: "Alert message", message: "Registration not perform Successfully..", preferredStyle: .alert)
                        
                        let ok1 = UIAlertAction(title: "OK", style: .default, handler: { (dt) in
                            
                            let st = self.navigationController?.popViewController(animated: true);
                            print(st!);
                        })
                        alt.addAction(ok1);
                        self.present(alt, animated: true, completion:nil)
                    }
                    else
                    {
                        let alt = UIAlertController(title: "Confirmation", message: "Registered", preferredStyle: .alert)
                        let ok1 = UIAlertAction(title: "OK", style: .default, handler: { (dt) in
                            
                            let st = self.navigationController?.popViewController(animated: true);
                            print(st!);
                        })
                        alt.addAction(ok1);
                        self.present(alt, animated: true, completion:nil)
                    }
                }
                
            }
            datatask.resume()
        }catch  {
        }
    }
//for validation and verification
    func isValidEmail(email : String) -> Bool {
        
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}";
        let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx);
        let result = emailTest.evaluate(with: email);
        return result;
    }
    func isValidPassword(pwd : String) -> Bool {
        
        //Minimum 6 Max 8 characters at least 1 Alphabet, 1 Number and 1 Special Character:
        let PHONE_REGEX = "^(?=.*[A-Za-z])(?=.*\\d)(?=.*[$@$!%*#?&])[A-Za-z\\d$@$!%*#?&]{6,12}$"
        let phoneTest = NSPredicate(format: "SELF MATCHES %@", PHONE_REGEX)
        let result =  phoneTest.evaluate(with: pwd)
        return result
    }
   
    @IBAction func Password(_ sender: Any) {
        if isValidPassword(pwd: txtpassword.text!) {
            
            txtpassword.rightViewMode = .never
            txtpassword.clipsToBounds = true
            txtpassword.layer.borderWidth = 1
            txtpassword.layer.borderColor = UIColor.green.cgColor
        }
        else {
            
            txtpassword.rightViewMode = .whileEditing
            let imgview = UIImageView(image: UIImage(named: "if_Help_mark_query_question_support_talk_271504.png"))
            txtpassword.rightView = imgview
            txtpassword.clipsToBounds = true
            txtpassword.layer.borderWidth = 1
            txtpassword.layer.borderColor = UIColor.red.cgColor
        }
        instruction.text = "Enter in this format : Minimum 6 Max 12 characters at least 1 Alphabet, 1 Number and 1 Special Character:"
        
    }
    
    
   

}
