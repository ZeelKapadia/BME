//
//  CustCellForDemo.swift
//  screens
//
//  Created by Zeel Kapadia on 29/01/19.
//  Copyright © 2019 TOPS. All rights reserved.
//

import UIKit

class CustCellForDemo: UITableViewCell {

    @IBOutlet weak var second: UILabel!
    @IBOutlet weak var minute: UILabel!
    @IBOutlet weak var hour: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
