//
//  CustResult.swift
//  screens
//
//  Created by Zeel Kapadia on 31/01/19.
//  Copyright © 2019 TOPS. All rights reserved.
//

import UIKit

class CustResult: UITableViewCell {

    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
