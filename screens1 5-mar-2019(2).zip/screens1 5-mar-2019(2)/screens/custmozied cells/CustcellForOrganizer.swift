//
//  CustcellForOrganizer.swift
//  screens
//
//  Created by Zeel Kapadia on 07/02/19.
//  Copyright © 2019 TOPS. All rights reserved.
//

import UIKit

class CustcellForOrganizer: UITableViewCell {

    @IBOutlet weak var lbl_eventName: UILabel!
    @IBOutlet weak var img: UIImageView!
    @IBOutlet weak var btnPlay: UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
