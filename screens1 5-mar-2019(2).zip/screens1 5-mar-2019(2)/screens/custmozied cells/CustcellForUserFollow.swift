//
//  CustcellForUserFollow.swift
//  screens
//
//  Created by Zeel Kapadia on 10/02/19.
//  Copyright © 2019 TOPS. All rights reserved.
//

import UIKit

class CustcellForUserFollow: UITableViewCell {

    @IBOutlet weak var img: UIImageView!
    @IBOutlet weak var name: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
