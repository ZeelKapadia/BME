//
//  CustCellForResult.swift
//  screens
//
//  Created by Zeel Kapadia on 14/02/19.
//  Copyright © 2019 TOPS. All rights reserved.
//

import UIKit

class CustCellForResult: UITableViewCell {

    @IBOutlet weak var EventName: UILabel!
    @IBOutlet weak var BannerImage: UIImageView!
    @IBOutlet weak var ParticipantprofileImage: UIImageView!
    @IBOutlet weak var ParticipantName: UILabel!
    @IBOutlet weak var PositivePercentage: UILabel!
    @IBOutlet weak var NegativePercentage: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
