//
//  customTableViewCell.swift
//  screens
//
//  Created by Zeel Kapadia on 12/01/19.
//  Copyright © 2019 TOPS. All rights reserved.
//

import UIKit

class customTableViewCell: UITableViewCell {

    @IBOutlet weak var img: UIImageView!
    @IBOutlet weak var event_name: UILabel!
    @IBOutlet weak var event_desc: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
