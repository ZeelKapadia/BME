//
//  CustCellForParticipant.swift
//  screens
//
//  Created by MAC2 on 28/02/19.
//  Copyright © 2019 TOPS. All rights reserved.
//

import UIKit

class CustCellForParticipant: UITableViewCell {

    @IBOutlet weak var imgvideo: UIImageView!
    
    @IBOutlet weak var btnPlay: UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
