//
//  CellForProfile.swift
//  screens
//
//  Created by Zeel Kapadia on 21/01/19.
//  Copyright © 2019 TOPS. All rights reserved.
//

import UIKit


class CellForProfile: UITableViewCell {

    @IBOutlet weak var imgdata: UIImageView!
    @IBOutlet weak var label: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
