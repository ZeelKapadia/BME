//
//  custcellshowmore.swift
//  screens
//
//  Created by Zeel Kapadia on 12/01/19.
//  Copyright © 2019 TOPS. All rights reserved.
//

import UIKit

class custcellshowmore: UITableViewCell {

    @IBOutlet weak var img: UIImageView!
    @IBOutlet weak var event_name: UILabel!
    @IBOutlet weak var result: UILabel!
    @IBOutlet weak var status: UILabel!
    @IBOutlet weak var Ending_time: UILabel!
    @IBOutlet weak var Starting_time: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    }

}
