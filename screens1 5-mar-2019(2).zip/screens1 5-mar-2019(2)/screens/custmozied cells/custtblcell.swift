//
//  custtblcell.swift
//  screens
//
//  Created by Zeel Kapadia on 12/01/19.
//  Copyright © 2019 TOPS. All rights reserved.
//

import UIKit

class custtblcell: UITableViewCell {

    @IBOutlet weak var img: UIImageView!
    @IBOutlet weak var event_name: UILabel!
    @IBOutlet weak var event_desc: UILabel!
    @IBOutlet weak var btnshowmore: UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

       
    }

    
}
