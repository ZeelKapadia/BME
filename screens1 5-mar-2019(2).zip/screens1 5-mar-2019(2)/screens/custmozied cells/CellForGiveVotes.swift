//
//  CellForGiveVotes.swift
//  screens
//
//  Created by Zeel Kapadia on 25/01/19.
//  Copyright © 2019 TOPS. All rights reserved.
//

import UIKit

class CellForGiveVotes: UITableViewCell {
    
   
    @IBOutlet weak var lbl_name: UILabel!
    @IBOutlet weak var posVote: UIButton!
    @IBOutlet weak var btnplay: UIButton!
    @IBOutlet weak var imgVideoImage: UIImageView!
    @IBOutlet weak var nagVote: UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
