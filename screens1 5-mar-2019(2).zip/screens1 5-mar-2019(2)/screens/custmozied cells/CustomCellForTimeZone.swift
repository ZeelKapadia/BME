//
//  CustomCellForTimeZone.swift
//  screens
//
//  Created by Zeel Kapadia on 20/01/19.
//  Copyright © 2019 TOPS. All rights reserved.
//

import UIKit

class CustomCellForTimeZone: UITableViewCell {

    @IBOutlet weak var imgForEvent: UIImageView!
    
    @IBOutlet weak var btn_check_in: UIButton!
    @IBOutlet weak var lbl_event_name: UILabel!
    @IBOutlet weak var Status: UILabel!
    
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
