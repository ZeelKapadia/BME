//
//  show_participants.swift
//  screens
//
//  Created by Zeel Kapadia on 15/01/19.
//  Copyright © 2019 TOPS. All rights reserved.
//
import SDWebImage

import UIKit

class show_participants: UIViewController,UITableViewDataSource,UITableViewDelegate,FetchDelegate,WriteDelegate{
   
    var Aodisc : [[String:Any]] = []
    var disc :[String:Any] = [:]
    var Target_u_t_id : String = ""
    var Source_u_t_id : String = ""
    
    @IBOutlet weak var tblshow: UITableView!
    @IBOutlet weak var btnHome: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        btnHome.layer.cornerRadius = btnHome.layer.frame.height / 2;
        btnHome.clipsToBounds = true
        Getdata()
        getLoginData()
    }
    func putDictionary(str: String) {
        print(str)
    }
    func Getdata() {
        let objClass = dataFetch()
        objClass.delegate = self
        objClass.fetch_data(Filename: "ParticipantFetch.php")
    }
    func getResponseData(arrDisc: [[String : Any]]) {
        if arrDisc.count > 0{
        Aodisc = arrDisc
        }
        tblshow.reloadData()
    }
    func getResponseDataAgain(arrDisc: [[String : Any]]) {
        
    }
    func hidebars() {
        self.navigationController?.navigationBar.isHidden = true
        self.tabBarController?.tabBar.isHidden = true
    }
    //for table view designing
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return Aodisc.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        disc = Aodisc[indexPath.row]
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! CustcellForUserFollow
        let fname = disc["user_fname"] as! String
        let lname = disc["user_lname"] as! String
        let fullname = fname + lname
        Target_u_t_id = disc["user_id"] as! String
        let imgData = disc["image"] as! String;
        let url = "http://localhost/votingdb/"
        let strUrl = url + imgData
        let finalUrl = URL(string: strUrl)
        do{
            let imgData = try Data(contentsOf: finalUrl!)
            cell.img.image = UIImage(data: imgData)
        }catch{
        }
        cell.name.text = fullname
        return cell
    }
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true;
    }
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        tableView.reloadData();
        }
    func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]? {
        let Follow = UITableViewRowAction(style: .default, title: "Follow"){(rowaction,indexPath)in
            let objWrite = dataWrite()
            objWrite.delegate = self
            let discForFollow = ["Source_u_t_id":self.Source_u_t_id,"Target_u_t_id":self.Target_u_t_id]
            objWrite.WriteData(FileName: "Follow.php", DiscData: discForFollow)
            let alt = UIAlertController(title: "followers add", message: "you are now follow the participant", preferredStyle: .actionSheet)
            self.present(alt, animated: true, completion: nil)
            self.dismiss(animated: true, completion: nil)
        }
        return [Follow];
    }
   
    @IBAction func btnhome(_ sender: Any) {
        let stb = self.storyboard?.instantiateViewController(withIdentifier: "Usertab")
        self.navigationController?.pushViewController(stb!, animated: true)
    }
    func getPath() -> String {
        let arr = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        let path = arr[0]
        let finalPath = path.appending("/userLogin.plist")
        print(finalPath)
        return finalPath
    }
    func getLoginData() {
        let flm = FileManager()
        if flm.fileExists(atPath: getPath()) {
            var disc = NSDictionary(contentsOfFile: getPath()) as! [String:Any]
            let arr = disc["userRecord"] as! [[String:Any]]
            let brr = arr[0] ;
            Source_u_t_id = brr["user_id"] as! String
        }
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 90.0
    }
}
