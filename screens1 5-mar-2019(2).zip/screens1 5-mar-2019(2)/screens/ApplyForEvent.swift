//
//  ApplyForEvent.swift
//  screens
//
//  Created by Zeel Kapadia on 25/01/19.
//  Copyright © 2019 TOPS. All rights reserved.
//

import UIKit

class ApplyForEvent: UIViewController,DataUpdatedDelegate,FetchDelegate,UITableViewDelegate,UITableViewDataSource {
   
    @IBOutlet weak var tblDataFetch: UITableView!
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrShow.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        let disc = arrShow[indexPath.row]
        let fname = disc["user_fname"] as? String
        let lname = disc["user_lname"] as? String
        let name = fname! + lname!;
        cell.textLabel?.text = name
        return cell
    }
    

    @IBOutlet weak var BannerImage: UIImageView!
    var e_id :String = ""
    var discForEvent:[String:Any] = [:]
    var discForId:[String:Any] = [:]
    var arrShow:[[String:Any]] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        ShowParticipantList()
        checkLoginStatus()
        FetchAndDisplay()
    }
    func FetchAndDisplay() {
        let objClass = dataFetch()
        objClass.delegate = self
        objClass.fetch_data(Filename: "eventFetchMulTable.php")
    }
    func getResponseData(arrDisc: [[String : Any]]) {
        if arrDisc.count > 0 {
            arrShow = arrDisc
        }
        tblDataFetch.reloadData()
    }
    
    func getResponseDataAgain(arrDisc: [[String : Any]]) {
        
    }
    func ShowParticipantList() {
        let imgData = discForEvent["Banner_image"] as! String;
        let url = "http://localhost/votingdb/"
        let strUrl = url + imgData
        let finalUrl = URL(string: strUrl)
        do{
            let imgData = try Data(contentsOf: finalUrl!)
            BannerImage.image = UIImage(data: imgData)
        }catch{
        }
    }
    @IBAction func btn_Apply(_ sender: Any) {
       updateForParticipantId()
        let stb = self.storyboard?.instantiateViewController(withIdentifier: "Upload") as! Upload;
        stb.e_id = discForEvent["E_id"] as! String
self.navigationController?.pushViewController(stb, animated: true)
    }
    func updateForParticipantId() {
        let objClass = DataUpdate()
        objClass.delegate = self
        let disc1 = ["E_id":discForEvent["E_id"]!,"P_id":discForId["user_id"]!] as [String:Any]
        objClass.RecordUpdate(FileName: "eventUpdateParticipantId.php", DiscData: disc1)
    }
    func Update(str: String) {
        print(str);
    }
    
    func UpdateAgain(str: String) {
    }
    func getPath() -> String {
        
        let arr = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        let path = arr[0]
        let finalPath = path.appending("/userLogin.plist")
        print(finalPath)
        return finalPath
    }
    func checkLoginStatus() {
        
        let flm = FileManager()
        if flm.fileExists(atPath: getPath()) {
            
            var disc = NSDictionary(contentsOfFile: getPath()) as! [String:Any]
            let arr = disc["userRecord"] as! [[String:Any]]
            if arr.count == 1 {
                discForId = arr[0]
            }
            
        }
    }

}
