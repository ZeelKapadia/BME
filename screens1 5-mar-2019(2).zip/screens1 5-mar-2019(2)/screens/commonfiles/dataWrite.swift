//
//  dataWrite.swift
//  screens
//
//  Created by Zeel Kapadia on 21/01/19.
//  Copyright © 2019 TOPS. All rights reserved.
//

import UIKit
protocol WriteDelegate {
    func putDictionary(str:String)
}
class dataWrite: NSObject {
    var delegate : WriteDelegate?

    func WriteData(FileName : String , DiscData : [String:Any]) {
        let str = "http://localhost/votingdb/"
        let path = str + FileName
        do {
            let body = try JSONSerialization.data(withJSONObject: DiscData, options: [])
            let url = URL(string: path)
            var request = URLRequest(url: url!)
            request.addValue(String(body.count), forHTTPHeaderField: "Content-Length")
            request.httpBody = body
            request.httpMethod = "POST"
            let session = URLSession.shared
            let datatask = session.dataTask(with: request){ (data1, resp, err) in
                
                let result = String(data: data1!, encoding: String.Encoding.utf8)
                print(result!)
                DispatchQueue.main.async {
                    
                    self.delegate?.putDictionary(str: result!)

                }
            }
            datatask.resume()
        }catch  {}
    }
}
