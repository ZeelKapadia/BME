//
//  dataFetch.swift
//  screens
//
//  Created by Zeel Kapadia on 21/01/19.
//  Copyright © 2019 TOPS. All rights reserved.
//

import UIKit

@objc protocol FetchDelegate {
    
    func getResponseData(arrDisc : [[String:Any]])
    func getResponseDataAgain(arrDisc : [[String:Any]])
    @objc optional func getUniqueData(arrDisc : [[String:Any]])
    @objc optional func getUniqueDataRes(str : String)
}

class dataFetch: NSObject {
    
    var delegate : FetchDelegate?
    
    func fetch_data(Filename : String){
        
        let str = "http://localhost/votingdb/"
        let file = str + Filename
        let url = URL(string: file)
        
        let request = URLRequest(url: url!)
        
        let session = URLSession.shared
        
        let datatask = session.dataTask(with: request) { (data1, resp, err) in
            
            let result = String(data: data1!, encoding: String.Encoding.utf8)
            print(result!)
            do{
                
                let jsondata = try JSONSerialization.jsonObject(with: data1!, options: []) as! [[String : Any]]
                DispatchQueue.main.async{

                        self.delegate?.getResponseData(arrDisc:jsondata)
                }
            }
            catch{
                
            }
            
        }
        datatask.resume()
        
    }
    func fetch_data_again(Filename : String){
        
        let str = "http://localhost/votingdb/"
        let file = str + Filename
        let url = URL(string: file)
        
        let request = URLRequest(url: url!)
        
        let session = URLSession.shared
        
        let datatask = session.dataTask(with: request) { (data1, resp, err) in
            
            let result = String(data: data1!, encoding: String.Encoding.utf8)
            print(result!)
            do{
                
                let jsondata = try JSONSerialization.jsonObject(with: data1!, options: []) as! [[String : Any]]
                DispatchQueue.main.async{
                    
                    if jsondata.count > 0{
                        
                        self.delegate?.getResponseDataAgain(arrDisc:jsondata)
                    }
                }
            }
            catch{
                
            }
            
        }
        datatask.resume()
    }
    func getUniqueData(FileName : String , DiscData : [String:Any]) {
        let str = "http://localhost/votingdb/"
        let path = str + FileName
        do {
            let body = try JSONSerialization.data(withJSONObject: DiscData, options: [])
            let url = URL(string: path)
            var request = URLRequest(url: url!)
            request.addValue(String(body.count), forHTTPHeaderField: "Content-Length")
            request.httpBody = body
            request.httpMethod = "POST"
            let session = URLSession.shared
            let datatask = session.dataTask(with: request){ (data1, resp, err) in
                
                let result = String(data: data1!, encoding: String.Encoding.utf8)
                print(result!)
                DispatchQueue.main.async {
                    
                    do{
                        let jsonData = try JSONSerialization.jsonObject(with: data1!, options: []) as! [[String:Any]]
                        self.delegate?.getUniqueData!(arrDisc: jsonData)
                    }catch{
                        
                    }
                }
            }
            datatask.resume()
        }catch  {}
    }
    func getUniqueDataRes(FileName : String , DiscData : [String:Any]) {
        let str = "http://localhost/votingdb/"
        let path = str + FileName
        do {
            let body = try JSONSerialization.data(withJSONObject: DiscData, options: [])
            let url = URL(string: path)
            var request = URLRequest(url: url!)
            request.addValue(String(body.count), forHTTPHeaderField: "Content-Length")
            request.httpBody = body
            request.httpMethod = "POST"
            let session = URLSession.shared
            let datatask = session.dataTask(with: request){ (data1, resp, err) in
                
                let result = String(data: data1!, encoding: String.Encoding.utf8)
                print(result!)
             
                        self.delegate?.getUniqueDataRes!(str: result!)
                
                }
            datatask.resume()
        }catch  {}
    }
}
