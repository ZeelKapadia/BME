//
//  checkin demo.swift
//  screens
//
//  Created by Zeel Kapadia on 29/01/19.
//  Copyright © 2019 TOPS. All rights reserved.
//

import UIKit

class checkin_demo: UIViewController,UITableViewDelegate,UITableViewDataSource,FetchDelegate {
   
    @IBOutlet weak var tbldemodata: UITableView!
    
    var timer = Timer()
    var disc:[String:Any] = [:]
    var disc1 :[String:Int] = [:]
    var arr: [[String:Any]] = []
    var hour :Int?
    var minute :Int?
    var second :Int?
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arr.count;
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! CustCellForDemo
        disc = arr[indexPath.row]
        let tempStartDate = disc["Start_time"] as! String
        let tempEndDate = disc["End_time"] as! String
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        let currDate = Date()
        let currentDateStr = dateFormatter.string(from: currDate)
        
       if currentDateStr == tempStartDate {
        let dateAInt  = Int(currentDateStr)!
       
        let dateA = dateFormatter.date(from: currentDateStr)
        let dateB = dateFormatter.date(from: tempEndDate)
            
      /*  if dateB >= dateA{
            let diff : Int = dateB - dateA
                hour = diff * 24;
            minute = hour! * 60;
            second = minute! * 60;
          print(diff)
            print(hour!)
            print(minute!)
            print(second!)
          }
        */}
        cell.hour.text = "\(hour)"
        cell.minute.text = "\(minute)"
        cell.second.text = "\(second)"
        return cell
    }
    func getResponseData(arrDisc: [[String : Any]]) {
        if arrDisc.count >= 1{
            arr = arrDisc
        }
        tbldemodata.reloadData()
    }
    
    func getResponseDataAgain(arrDisc: [[String : Any]]) {
       
    }
    
    func getdata() {
        let objClass = dataFetch()
        objClass.delegate = self
        objClass.fetch_data(Filename: "votingManageFetchTime.php")
    }
    func count() {
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        getdata()
        timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(self.count) , userInfo: nil, repeats: true)
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 110.0
    }
 
}
