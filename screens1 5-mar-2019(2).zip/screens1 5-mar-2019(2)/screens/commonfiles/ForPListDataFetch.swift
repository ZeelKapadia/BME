//
//  ForPListDataFetch.swift
//  screens
//
//  Created by Zeel Kapadia on 25/01/19.
//  Copyright © 2019 TOPS. All rights reserved.
//

import UIKit

class ForPListDataFetch: NSObject {

}
