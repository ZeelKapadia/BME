//
//  event1.swift
//  screens
//
//  Created by Zeel Kapadia on 11/01/19.
//  Copyright © 2019 TOPS. All rights reserved.
//

import UIKit

class event1: UIView {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
