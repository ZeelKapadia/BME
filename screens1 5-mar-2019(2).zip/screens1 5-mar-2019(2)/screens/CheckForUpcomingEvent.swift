//
//  CheckForUpcomingEvent.swift
//  screens
//
//  Created by MAC2 on 01/03/19.
//  Copyright © 2019 TOPS. All rights reserved.
//

import UIKit

class CheckForUpcomingEvent: UIViewController,FetchDelegate,UITableViewDelegate,UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrForData.count
    }
    
    @IBOutlet weak var tbldata: UITableView!
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let disc = arrForData[indexPath.row]
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        cell.textLabel?.text = disc["E_name"] as? String
        return cell
    }
    
    func getResponseData(arrDisc: [[String : Any]]) {
        if arrDisc.count > 0 {
            arrForData = arrDisc
             tbldata.reloadData()
        }else{
            alert()
        }
    }
    func alert()  {
        let alt = UIAlertController(title: "event not found", message: "there is not any event for you", preferredStyle: .actionSheet)
        let ok = UIAlertAction(title: "ok", style: .default, handler: ({action in
            let stb = self.storyboard?.instantiateViewController(withIdentifier: "Usertab")
            self.navigationController?.pushViewController(stb!, animated: true)
        }))
        alt.addAction(ok)
        self.present(alt, animated: true, completion: nil)
    }
    func getResponseDataAgain(arrDisc: [[String : Any]]) {
        
    }
    
    var arrForData : [[String:Any]] = []
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        fetch()
    }
    func fetch() {
        let objClass = dataFetch()
        objClass.delegate = self
        objClass.fetch_data(Filename: "UpComingEvent.php")
    }

}
