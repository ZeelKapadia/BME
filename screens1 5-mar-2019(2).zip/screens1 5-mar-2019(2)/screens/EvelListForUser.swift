//
//  EvelListForUser.swift
//  screens
//
//  Created by Zeel Kapadia on 06/02/19.
//  Copyright © 2019 TOPS. All rights reserved.
//

import UIKit

class EvelListForUser: UIViewController,UITableViewDataSource,UITableViewDelegate,FetchDelegate {
   
    @IBOutlet weak var tblshowevent: UITableView!
    
    var aod :[[String:Any]] = []
    var dics :[String:Any] = [:]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        createObj()
    }
    func createObj() {
       let objClass = dataFetch()
        objClass.delegate = self
        objClass.fetch_data(Filename: "eventVotingFetch.php")
    }
    func getResponseData(arrDisc: [[String : Any]]) {
        if arrDisc.count > 0{
            aod = arrDisc
        }
        tblshowevent.reloadData()
    }
    func getResponseDataAgain(arrDisc: [[String : Any]]) {
        
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return aod.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        dics = aod[indexPath.row]
        let e_name = dics["E_name"] as! String
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        if dics["E_Status"]as? String == "Complete" {
            cell.textLabel?.text = e_name
        }
        cell.textLabel?.text = e_name;
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let stb = self.storyboard?.instantiateViewController(withIdentifier: "Result") as! Result
        let e_id = (dics["E_id"] as? NSString)?.integerValue
        stb.e_id = e_id!
        self.navigationController?.pushViewController(stb, animated: true)
    }
}
