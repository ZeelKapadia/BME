//
//  selectTable.swift
//  screens
//
//  Created by vinen glasswala on 07/03/19.
//  Copyright © 2019 TOPS. All rights reserved.
//

import UIKit

class selectTable: UIViewController ,FetchDelegate,UITableViewDelegate,UITableViewDataSource{
    var disc : [String:Any] = [:]
    @IBOutlet weak var tblshowEvents: UITableView!
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arr.count;
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
         disc = arr[indexPath.row]
        let e_name = disc["E_name"] as! String;
        cell.textLabel?.text = "\(e_name)"
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        disc = arr[indexPath.row]
        let stb = self.storyboard?.instantiateViewController(withIdentifier: "Result") as! Result
        stb.E_id = disc["E_id"] as! String
        self.navigationController?.pushViewController(stb, animated: true)
    }
    func getResponseData(arrDisc: [[String : Any]]) {
        if arrDisc.count > 0{
            arr = arrDisc
        }
        tblshowEvents.reloadData()
    }
    var arr : [[String:Any]] = []
    func getResponseDataAgain(arrDisc: [[String : Any]]) {
        
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()
        fetch()
    }
    func fetch()  {
        let objClass = dataFetch()
        objClass.delegate = self
        objClass.fetch_data(Filename: "EventDesc.php")
    }
    
}
