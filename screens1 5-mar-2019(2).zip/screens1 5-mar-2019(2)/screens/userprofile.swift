import UIKit

class userprofile: UIViewController,UITableViewDelegate,UITableViewDataSource {
    var brr : [[String:Any]] = [];
    
    
    @IBOutlet weak var tbldata: UITableView!
    @IBOutlet weak var SegmentChangedState: UISegmentedControl!
    
    @IBOutlet weak var img: UIImageView!
    var disc:[String:Any] = [:]
    override func viewDidLoad() {
        super.viewDidLoad()
        showSegment()
        img.layer.cornerRadius = img.layer.frame.size.width / 2;
        img.clipsToBounds  = true;
    
  //getLoginData()
  
    }
    func getPath() -> String {
        let arr = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        let path = arr[0]
        let finalPath = path.appending("/userLogin.plist")
        print(finalPath)
        return finalPath
    }
    override func viewWillAppear(_ animated: Bool) {
        getLoginData()
        
    }
func getLoginData() {
    
    let flm = FileManager()
    if flm.fileExists(atPath: getPath()) {
        
        var disc = NSDictionary(contentsOfFile: getPath()) as! [String:Any]
        brr = disc["userRecord"] as! [[String:Any]]
        let getDisc = brr[0];
        let imgName = getDisc["image"] as! String
        let url = "http://localhost/votingdb/"
        let strUrl = url + imgName
        let finalUrl = URL(string: strUrl)
        do{
            let imgData = try Data(contentsOf: finalUrl!)
            img.image = UIImage(data: imgData)
        }catch{
        }
        tbldata.reloadData()
        }
    }
   @IBAction func edit_profile(_ sender: Any) {
        let stb = self.storyboard?.instantiateViewController(withIdentifier: "profile_user")as! profile_user;
        self.navigationController? .pushViewController(stb, animated: true)       
    }
    @IBAction func showmenu(_ sender: Any) {
        
        let stb = self.storyboard?.instantiateViewController(withIdentifier: "user_menu")as! user_menu;
        self.navigationController? .pushViewController(stb, animated: true)
}
    //for table view
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 4;
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell{
       
       disc = brr[indexPath.section]
        UserDefaults.standard.dictionary(forKey: "disc");
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        if indexPath.row == 0 {
            
            cell.textLabel?.text = disc["user_fname"] as? String
        }
        if indexPath.row == 1 {
            cell.textLabel?.text = disc["user_lname"] as? String
        }
        if indexPath.row == 2 {
            cell.textLabel?.text = disc["user_email"] as? String
        }
        if indexPath.row == 3{
            cell.textLabel?.text = disc["user_type"] as? String
        }
        return cell;
    }
// to show the segment view
    func showSegment()  {
        UserDefaults.standard.dictionary(forKey: "disc")
        if disc["user_type"] as! String == "Organizer"{
            SegmentChangedState.isHidden = false
        }
        else{
            SegmentChangedState.isHidden = true
        }
    }
    //for change the Roles
    
    @IBAction func changing_roles(_ sender: Any) {
        if SegmentChangedState.selectedSegmentIndex == 0{
            let stb = storyboard?.instantiateViewController(withIdentifier: "org_pages")
            self.navigationController?.pushViewController(stb!, animated: true)
        }
        else if SegmentChangedState.selectedSegmentIndex == 1{
                let stb = self.storyboard?.instantiateViewController(withIdentifier: "participanttab")
            self.navigationController?.pushViewController(stb!, animated: true)
        }
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
     
    }
}
