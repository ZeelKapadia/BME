import UIKit
import Photos
import MobileCoreServices
import AVFoundation
import SDWebImage

class Upload: UIViewController,UIImagePickerControllerDelegate,UINavigationControllerDelegate ,FetchDelegate{
   
    @IBOutlet weak var imgView: UIImageView!
    @IBOutlet weak var btnImages: UIButton!
    @IBOutlet weak var btnVideo: UIButton!
    @IBOutlet weak var btnUpload: UIButton!
    
    var e_id : String = ""
    var brr :[[String:Any]] = []
   var disc1 : [String:Any] = [:]
    var flag : Int = 0

    var urlFinal = URL(string: "https://www.google.co.in/")
    var SelectedAssets : [PHAsset] = []
    var PhotoArray : [UIImage] = []
    var baseStrArray : [String] = []
     var responseStr : String = ""
    
    
    
/*    override func viewDidLoad() {
        super.viewDidLoad()
     //   hidebars()
       getLoginData()
        print(e_id)
    }
    func hidebars() {
        self.navigationController?.navigationBar.isHidden = true
        self.tabBarController?.tabBar.isHidden = true
    }*/
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        
        if flag == 0 {
            
            imgView.image = info[UIImagePickerControllerOriginalImage] as? UIImage
            self.dismiss(animated: true, completion: nil)
        }else{
            
            let videourl = info[UIImagePickerControllerMediaURL] as! URL
            print(videourl)
            urlFinal = videourl
            do {
                let test =  try Data(contentsOf: videourl, options: Data.ReadingOptions.alwaysMapped)
                print(test)
            }catch{
            }
            
            imgView.image = getThumbnailImage(forUrl: videourl)
            self.dismiss(animated: true, completion: nil)
        }
    }
    func getThumbnailImage(forUrl url: URL) -> UIImage? {
        let asset: AVAsset = AVAsset(url: url)
        let imageGenerator = AVAssetImageGenerator(asset: asset)
        
        do {
            let thumbnailImage = try imageGenerator.copyCGImage(at:CMTimeMake(1, 60) , actualTime: nil)
            return UIImage(cgImage: thumbnailImage)
        } catch let error {
            print(error)
        }
        return nil
    }
    @IBAction func btn_for_images(_ sender: Any) {
        flag = 0;
            let altF = UIAlertController(title: "Choose any one", message: "", preferredStyle: .actionSheet)
            let camera = UIAlertAction(title: "Camera", style: .default, handler:({action in
                let picker = UIImagePickerController()
                picker.sourceType = .camera
                picker.delegate = self;
                self.present(picker,animated: true,completion: nil)
            }))
            let photoLibrary = UIAlertAction(title: "PhotoLibrary", style: .default, handler: ({action in
                let picker = UIImagePickerController()
                picker.sourceType = .photoLibrary
                picker.delegate = self;
                self.present(picker,animated: true,completion: nil)
            }))
            altF.addAction(camera)
            altF.addAction(photoLibrary)
            self.present(altF, animated: true, completion: nil)
    }
 
    @IBAction func btn_for_videos(_ sender: Any) {
       Media()
    }
   /* func openGallary()  {
        PhotoArray.removeAll()
        baseStrArray.removeAll()
        print(PhotoArray);
        print(baseStrArray)
        let Vc = BSImagePickerViewController()
        self.bs_presentImagePickerController(Vc, animated: true, select: { (assets : PHAsset) -> Void in
            
        }, deselect: { (asset : PHAsset) -> Void in
            
        }, cancel: { (assets : [PHAsset]) -> Void in
            
        }, finish: { (assets : [PHAsset]) -> Void in
            for i in 0..<assets.count{
                self.SelectedAssets.append(assets[i])
            }
            self.convertAssetsToImages()
        }, completion: nil)
    }*/
    
    
    func convertAssetsToImages() {
 
 if SelectedAssets.count != 0 {
 
 for i in 0..<SelectedAssets.count{
 
 let manager = PHImageManager()
 let option = PHImageRequestOptions()
 var Thumbnail = UIImage()
 option.isSynchronous = true
 manager.requestImage(for: SelectedAssets[i], targetSize: CGSize(width: 200, height: 200), contentMode: .aspectFill, options: option) { (result, info) in
 
 Thumbnail = result!
 }
    let imgData = UIImagePNGRepresentation(Thumbnail)
    let baseStr = imgData?.base64EncodedString(options: Data.Base64EncodingOptions.lineLength64Characters)

    self.baseStrArray.append(baseStr!)
    let data = UIImagePNGRepresentation(Thumbnail)
    let newImage = UIImage(data: data!)
    self.PhotoArray.append(newImage! as UIImage)
    }
  //  DispatchQueue.main.async {
        self.imgView.animationImages = self.PhotoArray
        self.imgView.animationDuration = 5.0
        self.imgView.startAnimating()
 //   }
    }
 }
    // for videos
   
    // for uploading image
    func uploadimg() {
        let imgData = UIImagePNGRepresentation(imgView.image!)
        let baseStr = imgData?.base64EncodedString(options: Data.Base64EncodingOptions.lineLength64Characters)
            let fname = disc1["user_fname"] as! String
            let lname = disc1["user_lname"] as! String
            let name = fname + lname
            let str = "http://localhost/votingdb/upload.php"
           
            let disc : [String:Any] = ["pa_name":name,"pa_id":disc1["user_id"]!, "flag":flag, "Image_data":baseStr,"e_id" :e_id]
            do{
                let body = try JSONSerialization.data(withJSONObject: disc, options: [])
                let url = URL(string: str)
                var request = URLRequest(url: url!)
                request.addValue(String(body.count), forHTTPHeaderField: "Content-Length")
                request.httpBody = body
                request.httpMethod = "POST"
                let session = URLSession.shared
                let dataTask = session.dataTask(with: request) { (data1, resp1, err) in
                    
                    let result = String(data: data1!, encoding: String.Encoding.utf8)
                    print(result!)
                    self.responseStr = result!
                    DispatchQueue.main.async {
                        
                        if self.responseStr == "Inserted"{
                            
                            print("Success!")
                        }
                    }
                }
                dataTask.resume()
            }catch{
            }
     //   }
    }
//}
    // for uploading videos
    func uploadvideo() {
        do{
            
            let fname = disc1["user_fname"] as! String
            let lname = disc1["user_lname"] as! String
            let name = fname + lname
        let videoData = try Data(contentsOf: urlFinal!, options: Data.ReadingOptions.alwaysMapped)
        let baseStr = videoData.base64EncodedString(options: Data.Base64EncodingOptions.lineLength64Characters)
        
        let str = "http://localhost/votingdb/upload.php"
            let disc : [String : Any] = ["pa_name":name,"pa_id":disc1["user_id"]!,"flag":flag,"video_data":baseStr,"e_id":e_id]
        do {
            let body = try JSONSerialization.data(withJSONObject: disc, options: [])
            let url = URL(string: str)
            var request = URLRequest(url: url!)
            
            request.addValue(String(body.count), forHTTPHeaderField: "Content-Length")
            request.httpBody = body
            request.httpMethod = "POST"
            
            let session = URLSession.shared
            let dataTask = session.dataTask(with: request, completionHandler: { (data1, resp1, err) in
                
                let result = String(data: data1!, encoding: String.Encoding.utf8)
                print(result!)
                
                DispatchQueue.main.async {
                    
                    if result == "Inserted"{
                        
                        print("Success")
                    }
                }
            })
            dataTask.resume()
            
        } catch  {
            
        }
    }catch{}
    }
    //checking for the image or video
 
    @IBAction func btn_upload(_ sender: Any) {
        if flag == 0{
            uploadimg()
            moveToOriginalTab()
        }
        else if flag == 1{
            uploadvideo()
            moveToOriginalTab()
        }
    }
    func moveToOriginalTab() {
        let stb = self.storyboard?.instantiateViewController(withIdentifier: "participanttab")
        self.navigationController?.pushViewController(stb!, animated: true)
    }
    
    
    // to get the participant's id
    func getPath() -> String {
        
        let arr = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        let path = arr[0]
        let finalPath = path.appending("/userLogin.plist")
        print(finalPath)
        return finalPath
    }
    func getLoginData() {
        
        let flm = FileManager()
        if flm.fileExists(atPath: getPath()) {
            
            var disc = NSDictionary(contentsOfFile: getPath()) as! [String:Any]
            let crr = disc["userRecord"] as! [[String:Any]]
            let getDisc = crr[0];
            disc1 = getDisc;
         
        }
    }
    override func viewDidLoad() {
       getLoginData()
       fetching()
        
        btnUpload.layer.cornerRadius = btnUpload.layer.frame.height / 2;
        btnUpload.clipsToBounds = true
        btnVideo.layer.cornerRadius = btnVideo.layer.frame.height / 2;
        btnVideo.clipsToBounds = true
        btnImages.layer.cornerRadius = btnImages.layer.frame.height / 2;
        btnImages.clipsToBounds = true
    }
    override func viewWillAppear(_ animated: Bool) {
      //  fetching()
    }
    func fetching() {
        let objClass = dataFetch()
        objClass.delegate = self
        let dis : [String:Any] = ["pa_id":disc1["user_id"]!,"e_id":e_id]
        objClass.getUniqueDataRes(FileName: "checkForUpload.php", DiscData: dis)
    }
    func getResponseData(arrDisc: [[String : Any]]) {
    }
    
    func getResponseDataAgain(arrDisc: [[String : Any]]) {
    }
    func getUniqueDataRes(str: String) {
        print(str);
        if str == "can not inserted"{
            let alt  = UIAlertController(title: "cannot be insert", message: "you alrady upload your goods", preferredStyle: .actionSheet)
            let ok  = UIAlertAction(title: "ok", style: .default, handler: ({action in
                
                let stb = self.storyboard?.instantiateViewController(withIdentifier: "participanttab")
                self.navigationController?.pushViewController(stb!, animated: true)
            }))
            alt.addAction(ok)
            self.present(alt, animated: true, completion: nil)
        }
    }
    //for video
    func Media() {
        
        let picker = UIImagePickerController()
        picker.sourceType = .photoLibrary
        picker.mediaTypes = [kUTTypeMovie as String]
        picker.delegate = self
        self.flag = 1
        self.present(picker, animated: true, completion: nil)
    }

}
