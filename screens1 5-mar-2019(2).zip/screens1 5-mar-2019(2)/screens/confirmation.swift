//
//  confirmation.swift
//  screens
//
//  Created by Zeel Kapadia on 24/01/19.
//  Copyright © 2019 TOPS. All rights reserved.
//

import UIKit

class confirmation: UIViewController,FetchDelegate {
    
    func getResponseData(arrDisc: [[String : Any]]) {
        
    }
    
    func getResponseDataAgain(arrDisc: [[String : Any]]) {
        
    }
    
    var user_email :String = ""
    var disc : [String:Any] = [:]
    
    @IBOutlet weak var txtotp: UITextField!
    @IBOutlet weak var btnConfirm: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        fetch()
        btnConfirm.layer.cornerRadius = btnConfirm.layer.frame.height / 2;
        btnConfirm.clipsToBounds = true
    }
    func fetch() {
        let objClass = dataFetch()
        objClass.delegate = self
        objClass.getUniqueData(FileName: "OTPFetch", DiscData: ["user_email":user_email])
    }
    func getUniqueData(arrDisc: [[String : Any]]) {
        if arrDisc.count > 0 {
            disc = arrDisc[0];
        }
    }
    func generateRandomDigits(_ digitNumber: Int) -> String {
        var number = ""
        for i in 0..<digitNumber {
            var randomNumber = arc4random_uniform(10)
            while randomNumber == 0 && i == 0 {
                randomNumber = arc4random_uniform(10)
            }
            number += "\(randomNumber)"
        }
        return number
    }
    
    func showOtp() {
        let OTP = generateRandomDigits(6)
        _ = SweetAlert().showAlert("Good job!", subTitle: "Kindly find your OTP \(OTP)", style: AlertStyle.success)
    }
    
    @IBAction func senAgain(_ sender: Any) {
        showOtp()
    }
    @IBAction func confrim(_ sender: Any) {
       check()
    }
    func check() {
        if txtotp.text == "" {
            alert()
        }
        else
        {
            let otp = disc["OTP"] as! String
            if txtotp.text == otp{
                moveNextPage()
            }
            else{
                alert1()
            }
        }
    }
    func alert1() {
        let alt = UIAlertController(title: "NOT MATCHED", message: "please enter valid OTP", preferredStyle: .actionSheet)
        let ok = UIAlertAction(title: "OK", style: .default, handler: ({ action in
            self.showOtp()
        }))
        alt.addAction(ok)
        self.present(alt, animated: true, completion: nil)
    }
    func alert() {
        let alt = UIAlertController(title: "Empty Field Found", message: "You must have entered one time password", preferredStyle: .actionSheet)
        let ok = UIAlertAction(title: "OK", style: .default, handler: nil)
        alt.addAction(ok)
        self.present(alt, animated: true, completion: nil)
    }
    func moveNextPage() {
      let stb = self.storyboard?.instantiateViewController(withIdentifier: "change_password") as! change_password
        stb.u_email = user_email
        self.navigationController?.pushViewController(stb, animated: true)
    }
}
