

import UIKit

class org_events: UIViewController,UITableViewDataSource,UITableViewDelegate,FetchDelegate {
    var Aodisc : [[String:Any]] = []
    var disc : [String:Any] = [:]
    var discForUserId : [String:Any] = [:]
    var ename = ""
    var eventid = ""
    var userid = ""
    var min : Date?
    var max : Date?
    
    @IBOutlet weak var tblevent: UITableView!
    
    func getResponseData(arrDisc: [[String : Any]]) {
        if arrDisc.count > 0 {
            Aodisc = arrDisc
        }
        tblevent.reloadData()
    }
    func getResponseDataAgain(arrDisc: [[String : Any]]) {
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return Aodisc.count;
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        disc = Aodisc[indexPath.row]
        let userId : String = discForUserId["user_id"] as! String
        let orgId :String = disc["O_id"] as! String
        if userId == orgId {
            cell.textLabel?.text = disc["E_name"] as? String
        }
        return cell;
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
       let sdate = disc["Starting_date"] as? String
        let edate = disc["Ending_date"] as? String
        let frm = DateFormatter()
        frm.dateFormat = "yyyy-MM-DD"
        min = frm.date(from: sdate!)
        max = frm.date(from: edate!)
        disc = Aodisc[indexPath.row]
        ename = disc["E_name"] as! String
        eventid = disc["E_id"] as! String
        userid = discForUserId["user_id"] as! String
        let stb = self.storyboard?.instantiateViewController(withIdentifier: "set_timezone") as! set_timezone
        stb.eventid = eventid;
        stb.userid = userid;
//        stb.min = min;
//        stb.max = max;
        self.navigationController?.pushViewController(stb, animated:   true)
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        getLoginData()
        fetch_event_data()
     //self.navigationController?.navigationBar.isHidden = true
    }
    ///for database to fetch the events
    func fetch_event_data(){
        let objFetch = dataFetch()
        objFetch.delegate = self
        objFetch.fetch_data(Filename: "eventFetch.php")
    }
    
    func getPath() -> String {
        
        let arr = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        let path = arr[0]
        let finalPath = path.appending("/userLogin.plist")
        print(finalPath)
        return finalPath
    }
    func getLoginData() {
        
        let flm = FileManager()
        if flm.fileExists(atPath: getPath()) {
            
            var discForData = NSDictionary(contentsOfFile: getPath()) as! [String:Any]
            let brr = discForData["userRecord"] as! [[String:Any]]
            discForUserId = brr[0];
            
        }
    }
}
