//
//  Result.swift
//  screens
//
//  Created by MAC2 on 08/12/18.
//  Copyright © 2018 TOPS. All rights reserved.
//
//import SDWebImage

import UIKit

class Result: UIViewController,FetchDelegate,UITableViewDelegate,UITableViewDataSource{
    
    var awinner :[[String:Any]] = []
    @IBOutlet weak var btnHome: UIButton!
    @IBOutlet weak var tblwinner: UITableView!
    
    override func viewDidLoad() {
      fetch()
        btnHome.layer.cornerRadius = btnHome.layer.frame.size.height / 2
        btnHome.clipsToBounds = true
    }
    
    func fetch() {
        let objClass = dataFetch()
        objClass.delegate = self
        objClass.fetch_data(Filename: "result.php")
    }

    func getResponseData(arrDisc: [[String : Any]]) {
        if arrDisc.count > 0 {
            awinner = arrDisc
        }
        tblwinner.reloadData()
    }
    
    func getResponseDataAgain(arrDisc: [[String : Any]]) {
        
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return awinner.count;
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! CustCellForResult
        let aodwinner = awinner[indexPath.row]
        let eventName = aodwinner["E_name"] as! String
        cell.EventName.text = "\(eventName)"
    let bimg = aodwinner["Banner_image"] as! String
       let str = "http://localhost/votingdb/"
        let url = URL(string: (str + bimg))
        do{
        let data = try Data(contentsOf: url!)
        cell.BannerImage.image = UIImage(data: data)
        }
        catch{}
        let pimg = aodwinner["image"] as! String
        let purl = URL(string: (str + pimg))
        do{
            let pdata = try Data(contentsOf: purl!)
            cell.ParticipantprofileImage.image = UIImage(data: pdata)
        }
        catch{}
        let fname = aodwinner["user_fname"] as! String
        let lname = aodwinner["user_lname"] as! String
        let name = fname + lname
        cell.ParticipantName.text = "\(name)"
        let pos = (aodwinner["positive"] as! NSString).integerValue
        let neg = (aodwinner["negative"] as! NSString).integerValue
        let total = pos + neg;
        let posPer = (pos*100)/total;
        let negPer = (neg*100)/total;
        cell.PositivePercentage.text = "\(posPer) %"
        cell.NegativePercentage.text = "\(negPer) %"
        cell.ParticipantprofileImage.layer.cornerRadius = cell.ParticipantprofileImage.layer.frame.size.height  / 2;
        cell.ParticipantprofileImage.clipsToBounds = true;
        
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 365.0
    }
}
