import UIKit
import SDWebImage


class participant_menu: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
   
    @IBOutlet weak var img: UIImageView!
    @IBOutlet weak var name: UILabel!
    
    let  arr = ["participants","result","Logout"];
    override func viewDidLoad() {
        super.viewDidLoad()
        hidebars()
        checkLoginStatus()
        
    }
    func hidebars() {
        self.navigationController?.navigationBar.isHidden = true
        self.tabBarController?.tabBar.isHidden = true
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arr.count;
    }
    override func viewWillAppear(_ animated: Bool) {
   //     hidebars()
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        cell.textLabel?.text = arr[indexPath.row];
        return cell;
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print(arr[indexPath.row])
        if(arr[indexPath.row] == "participants"){
            let stb = self.storyboard?.instantiateViewController(withIdentifier: "Participants")as! Participants;
            self.navigationController? .pushViewController(stb, animated: true)
        }
       else if(arr[indexPath.row] == "events participated"){
            let stb = self.storyboard?.instantiateViewController(withIdentifier: "EventParticipant")as! EventParticipant;
            self.navigationController? .pushViewController(stb, animated: true)
        }
        else if(arr[indexPath.row] == "result"){
            let stb = self.storyboard?.instantiateViewController(withIdentifier: "Result")as! Result;
            self.navigationController? .pushViewController(stb, animated: true)
        }
        else if(arr[indexPath.row] == "Logout"){
            destroyLoginData()
            moveToLogin()
        }
        
    }
    func moveToLogin() {
        let stb = storyboard?.instantiateViewController(withIdentifier: "login") as! ViewController
        self.navigationController?.pushViewController(stb, animated: true)
    }
    func destroyLoginData() {
        
        let flm = FileManager()
        if flm.fileExists(atPath: getPath()) {
            
            var disc = NSDictionary(contentsOfFile: getPath()) as! [String:Any]
            var arr = disc["userRecord"] as! [[String:Any]]
            arr.removeAll()
            disc["userRecord"] = arr
            let finalDisc = NSDictionary(dictionary: disc)
            finalDisc.write(toFile: getPath(), atomically: true)
            
        }
    }
    func getPath() -> String {
        
        let arr = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        let path = arr[0]
        let finalPath = path.appending("/userLogin.plist")
        print(finalPath)
        return finalPath
    }
    func checkLoginStatus() {
        
        let flm = FileManager()
        if flm.fileExists(atPath: getPath()) {
            
            var disc = NSDictionary(contentsOfFile: getPath()) as! [String:Any]
            let arr = disc["userRecord"] as! [[String:Any]]
            if arr.count == 1 {
                
                let getDisc = arr[0]
                let imgData = getDisc["image"] as! String;
                let url = "http://localhost/votingdb/"
                let strUrl = url + imgData
                let finalUrl = URL(string: strUrl)
                do{
                    let imgData = try Data(contentsOf: finalUrl!)
                    img.image = UIImage(data: imgData)
                    img.layer.cornerRadius = img.layer.frame.width / 2
                    img.layer.masksToBounds = true;
                }catch{
                }
                name.text = getDisc["user_fname"] as? String
                //userMenu.reloadData()
            }
            else
            {
                let alt = UIAlertController(title: "not login found", message: "Please login into the application", preferredStyle: .alert)
                let ok = UIAlertAction(title: "OK", style: .default, handler: ({action in
                    let stb = self.storyboard?.instantiateViewController(withIdentifier: "login") as! ViewController
                    self.navigationController?.pushViewController(stb, animated: true)
                }))
                alt.addAction(ok)
                self.present(alt, animated: true, completion: nil)
            }
        }
    }
    
    @IBAction func edit_profile(_ sender: Any) {
       let stb = storyboard?.instantiateViewController(withIdentifier: "profile_user") as! profile_user
        self.navigationController?.pushViewController(stb, animated: true)
    }
    
 }
