import UIKit
import SDWebImage

class ViewController: UIViewController,UINavigationBarDelegate {

    @IBOutlet weak var img: UIImageView!
    @IBOutlet weak var txt1: UITextField!
    @IBOutlet weak var txt2: UITextField!
    @IBOutlet weak var btnLogin: UIButton!
    
    @IBOutlet weak var btnSignin: UIButton!
    
    var login_arr : [[String : Any]] = []
    var uType : String = ""
    var email :String = ""
    var pass :String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        img.layer.cornerRadius = img.frame.size.height / 2;
        img.layer.masksToBounds = true
       txt1.placeholder = "Email ID";
       txt2.placeholder = "Password" ;
        createLoginData()
        checkLoginStatus()
        self.navigationController?.navigationBar.isHidden = true;
        self.tabBarController?.tabBar.isHidden = true;
        btnLogin.layer.cornerRadius = btnLogin.layer.frame.height / 2;
        btnLogin.clipsToBounds = true
        btnSignin.layer.cornerRadius = btnSignin.layer.frame.height / 2;
        btnSignin.clipsToBounds = true
    }
    
    //for hide the bars
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.navigationBar.isHidden = true;
        self.tabBarController?.tabBar.isHidden = true;
    }
    func checkLoginStatus() {
        
        let flm = FileManager()
        if flm.fileExists(atPath: getPath()) {
            
            var disc = NSDictionary(contentsOfFile: getPath()) as! [String:Any]
            var arr = disc["userRecord"] as! [[String:Any]]
            if arr.count == 1 {
                
                let disc = arr[0]
                self.uType = disc["user_type"] as! String
                if self.uType == "User" {
                    
                    print("success")
                    let stb = self.storyboard?.instantiateViewController(withIdentifier: "Usertab")
                    self.navigationController?.pushViewController(stb!, animated: false)
                    
                }
                else if self.uType == "Participant"{
                    
                    print("success")
                    let stb = self.storyboard?.instantiateViewController(withIdentifier: "participanttab")
                    self.navigationController?.pushViewController(stb!, animated: false)
                    
                }
                else if self.uType == "Organizer"{
                    
                    print("success")
                    let stb = self.storyboard?.instantiateViewController(withIdentifier: "org_tab")
                    self.navigationController?.pushViewController(stb!, animated: false)
                    
                }
            }
        }
    }
    func createLoginData() {
        
        let flm = FileManager()
        if !flm.fileExists(atPath: getPath()) {
            
            let arr : [[String:Any]] = []
            let disc : [String:Any] = ["userRecord":arr]
            let finalDisc = NSDictionary(dictionary: disc)
            finalDisc.write(toFile: getPath(), atomically: true)
        }
    }
    func getPath() -> String {
        
        let arr = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        let path = arr[0]
        let finalPath = path.appending("/userLogin.plist")
        print(finalPath)
        return finalPath
    }
    func insertLoginData() {
        
        let flm = FileManager()
        if flm.fileExists(atPath: getPath()) {
            
            var disc = NSDictionary(contentsOfFile: getPath()) as! [String:Any]
            var arr = disc["userRecord"] as! [[String:Any]]
            arr = login_arr
            disc["userRecord"] = arr
            let finalDisc = NSDictionary(dictionary: disc)
            finalDisc.write(toFile: getPath(), atomically: true)
            
        }
    }
    @IBAction func Login(_ sender: Any) {
    
        LoginCheck()
       
    }
    //check with the database if record found or not
    func LoginCheck(){
        
        let str = "http://localhost/votingdb/Login.php?user_email=\(txt1.text!)&&user_password=\(txt2.text!)"
       
        let url = URL(string: str)
        
        let request = URLRequest(url: url!)
        
        let session = URLSession.shared
        
        let datatask = session.dataTask(with: request) { (data1, resp, err) in
            
            let result = String(data: data1!, encoding: String.Encoding.utf8)
            print(result!)
            do{
            
                let jsondata = try JSONSerialization.jsonObject(with: data1!, options: []) as! [[String : Any]]
                
                self.login_arr = jsondata
                let disc = self.login_arr[0];
                self.email = disc["user_email"] as! String
                self.pass = disc["user_password"] as! String
                self.uType = disc["user_type"] as! String
                
                print(self.login_arr)
                DispatchQueue.main.async {
                    
                    self.insertLoginData()
                    if self.uType == "User" {
                        
                        print("success")
                        let stb = self.storyboard?.instantiateViewController(withIdentifier: "Usertab")
                        self.navigationController?.pushViewController(stb!, animated: false)
                        
                    }
                    else if self.uType == "Participant"{
                        
                        print("success")
                        let stb = self.storyboard?.instantiateViewController(withIdentifier: "participanttab")
                        self.navigationController?.pushViewController(stb!, animated: false)
                        
                    }
                    else if self.uType  == "Organizer"{
                        let stb  = self.storyboard?.instantiateViewController(withIdentifier: "org_tab")
                        self.navigationController?.pushViewController(stb!, animated: false);
                    }
                    
                    if self.email != self.txt1.text && self.pass != self.txt2.text {
                        let alt = UIAlertController(title: "try again", message: "user name and password does not match", preferredStyle: .alert)
                        
                        let ok1 = UIAlertAction(title: "OK", style: .default, handler: { (dt) in
                            
                        })
                        alt.addAction(ok1);
                        self.present(alt, animated: true, completion:nil)
                    }
//                    else{
//                        let stb = self.storyboard?.instantiateViewController(withIdentifier: "catogerize") as! catogerize
//                        self.navigationController?.pushViewController(stb, animated: false)
//                    }
                }
            }
            catch{}
        }
        datatask.resume()
    }
    // for move into another page
    @IBAction func signup(_ sender: Any) {
        let stb = self.storyboard?.instantiateViewController(withIdentifier: "signup")as! signup;
        self.navigationController? .pushViewController(stb, animated: true)
        
    }
    
    @IBAction func forgetPass(_ sender: Any) {
        let stb = self.storyboard?.instantiateViewController(withIdentifier: "forget_password") as! forget_password
        self.navigationController?.pushViewController(stb, animated: true)
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

