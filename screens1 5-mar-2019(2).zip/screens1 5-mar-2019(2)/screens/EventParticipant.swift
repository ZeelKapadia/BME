//
//  EventParticipant.swift
//  screens
//
//  Created by MAC2 on 08/12/18.
//  Copyright © 2018 TOPS. All rights reserved.
//
import SDWebImage

import UIKit

class EventParticipant: UIViewController ,UITableViewDataSource,UITableViewDelegate{
     var Aodisc : [[String:Any]] = [];
  
    @IBOutlet weak var tbleventinfo: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        fetch_event_data()
        hidebars()
    }
    func hidebars() {
        self.navigationController?.navigationBar.isHidden = true
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return Aodisc.count;
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! custtblcell
    let  desc = Aodisc[indexPath.row]
        let url = "http://localhost/votingdb/"
        let imgName = desc["Banner_image"] as! String;
        let strUrl = url + imgName
        let finalUrl = URL(string: strUrl)
        do{
            let imgData = try Data(contentsOf: finalUrl!)
            cell.img.image = UIImage(data: imgData)
        }catch{
            
        }
        cell.event_name.text = desc["E_name"] as? String;
        cell.event_desc.text = desc["desc"] as? String;
        cell.btnshowmore.tag = indexPath.row
        cell.btnshowmore.addTarget(self, action: #selector(showMore), for: .touchUpInside)
        return cell;
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 263.0
    }
  
    func fetch_event_data(){
        
        let str = "http://localhost/votingdb/eventFetch.php"
        
        let url = URL(string: str)
        
        let request = URLRequest(url: url!)
        
        let session = URLSession.shared
        let datatask = session.dataTask(with: request) { (data1, resp, err) in
            let result = String(data: data1!, encoding: String.Encoding.utf8)
            print(result!)
            do{
                let jsondata = try JSONSerialization.jsonObject(with: data1!, options: []) as! [[String : Any]]
                self.Aodisc = jsondata
                DispatchQueue.main.async{
                    self.tbleventinfo.reloadData();
                    print(self.Aodisc)
                }
            }
            catch{}
        }
        datatask.resume()
    }
    func showMore(_ sender : UIButton) {
        let disc = Aodisc[sender.tag]
        let stb = self.storyboard?.instantiateViewController(withIdentifier: "event_details") as! event_details
        stb.discForEvent = disc
        self.navigationController?.pushViewController(stb, animated: true)
    }
}
