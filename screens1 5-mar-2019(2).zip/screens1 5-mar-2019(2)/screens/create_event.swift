import UIKit
import SDWebImage

class create_event : UIViewController ,UIImagePickerControllerDelegate ,UINavigationControllerDelegate ,UITextFieldDelegate,UITextViewDelegate,WriteDelegate
{
    func putDictionary(str: String) {
        print(str)
    }
    
    @IBOutlet weak var img: UIImageView!
    @IBOutlet weak var btnImg: UIButton!
    @IBOutlet weak var E_name: UITextField!
    @IBOutlet weak var btnCreate: UIButton!
    @IBOutlet weak var sdate: UITextField!
    @IBOutlet weak var edate: UITextField!
    
    var datepicker = UIDatePicker()
    var brr : [[String:Any]] = []
    var disc1 : [String:Any] = [:]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        getLoginData()
        
        btnCreate.layer.cornerRadius = btnCreate.layer.frame.height / 2;
        btnCreate.clipsToBounds = true
        btnImg.layer.cornerRadius = btnImg.layer.frame.height / 2;
        btnImg.clipsToBounds = true
    }
    //make the placeholder for the textview
//    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
//        if (text == "\n") {
//            textView.resignFirstResponder()
//            return false
//        }
//        return true
//    }
    /*func textViewDidBeginEditing(_ textView: UITextView) {
        if(textView.text == "Add Event Description Here"){
            textView.text = ""
        }
        textView.becomeFirstResponder()
    }
    func textViewDidEndEditing(_ textView: UITextView) {
        if(textView.text == ""){
            textView.text = "Add Event Description Here"
        }
        textView.resignFirstResponder()
    }
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.navigationBar.isHidden = true;
    }*/
   
    //for designing side
    
   func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        
        if textField == sdate {
            
            showdate()
        }else if textField == edate{
            
            showdate1()
        }
        return true
    }
   func showdate1(){
        datepicker.datePickerMode = .date
        
        //ToolBar
        let toolbar = UIToolbar();
        toolbar.sizeToFit()
        let doneButton = UIBarButtonItem(title: "Done", style: .plain, target: self, action: #selector(donedatePicker1));
        let spaceButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonItem.SystemItem.flexibleSpace, target: nil, action: nil)
        let cancelButton = UIBarButtonItem(title: "Cancel", style: .plain, target: self, action: #selector(cancelDatePicker1));
        
        toolbar.setItems([doneButton,spaceButton,cancelButton], animated: false)
        
        edate.inputAccessoryView = toolbar
        edate.inputView = datepicker
    
    }
    func showdate() {
        datepicker.datePickerMode = .date
        
        //ToolBar
        let toolbar = UIToolbar();
        toolbar.sizeToFit()
        let doneButton = UIBarButtonItem(title: "Done", style: .plain, target: self, action: #selector(donedatePicker));
        let spaceButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonItem.SystemItem.flexibleSpace, target: nil, action: nil)
        let cancelButton = UIBarButtonItem(title: "Cancel", style: .plain, target: self, action: #selector(cancelDatePicker));
        
        toolbar.setItems([doneButton,spaceButton,cancelButton], animated: false)
        
    sdate.inputAccessoryView = toolbar
        sdate.inputView = datepicker
        
    }
    @IBAction func add_event_banner(_ sender: Any) {
        
        alert();
    }
    func alert() {
        let alt = UIAlertController(title: "Add event banner", message: "Select any option", preferredStyle: .alert)
        let camera = UIAlertAction(title: "Camera", style: .default, handler: {action in
            let picker = UIImagePickerController()
            picker.sourceType = .camera
            picker.delegate = self;
            self.present(picker,animated: true,completion: nil)
        })
        let gallery = UIAlertAction(title: "Gallery", style: .default, handler: {action in
            let picker = UIImagePickerController()
            picker.sourceType = .photoLibrary
            picker.delegate = self;
            self.present(picker,animated: true,completion: nil)
        })
        alt.addAction(camera);
        alt.addAction(gallery);
        
        
        self.present(alt, animated: true, completion: nil)
    }
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        let img1 = info[UIImagePickerControllerOriginalImage] as! UIImage;
        img.image = img1;
        self.dismiss(animated: true, completion:nil);
        
    }
    func alert1() {
        let alt = UIAlertController(title: "confirmation", message: "your event has created please set the timeduration for your event", preferredStyle: .alert)
        let ok = UIAlertAction(title: "Ok", style: .default, handler: ({action in
            let stb = self.storyboard?.instantiateViewController(withIdentifier: "org_events") as! org_events
            self.navigationController?.pushViewController(stb, animated: true)
            
        }))
        alt.addAction(ok);
        self.present(alt, animated: true, completion:nil)
        
    }
    func checkingData() {
        if E_name.text == ""{
            if sdate.text == ""{
                if edate.text == ""{
                    let alt = UIAlertController(title: "Empty Field Found", message: "You must have to set the Ending time for the Event", preferredStyle: .alert)
                    let ok = UIAlertAction(title: "Ok", style: .default, handler: nil)
                    alt.addAction(ok)
                    self.present(alt, animated: true, completion: nil)
                }
                let alt = UIAlertController(title: "Empty Field Found", message: "You must have to set the Starting time for the Event", preferredStyle: .alert)
                let ok = UIAlertAction(title: "Ok", style: .default, handler: nil)
                alt.addAction(ok)
                self.present(alt, animated: true, completion: nil)
            }
            let alt = UIAlertController(title: "Empty Field Found", message: "You must have to set the name of Event", preferredStyle: .alert)
            let ok = UIAlertAction(title: "Ok", style: .default, handler: nil)
            alt.addAction(ok)
            self.present(alt, animated: true, completion: nil)
        }
    }
    @IBAction func create_event_data(_ sender: Any) {
        checkingData()
        insertData()
        alert1()
    }
    //for data base side
    func insertData() {
        let imgData = UIImagePNGRepresentation(img.image!)
        let baseStr = imgData?.base64EncodedString(options: Data.Base64EncodingOptions.lineLength64Characters)
        let str = "http://localhost/votingdb/event.php"
        let disc : [String : Any] = ["E_name":E_name.text!,"O_id":(disc1["user_id"] as? NSString)?.integerValue,"Starting_date":sdate.text!,"Ending_date":edate.text!,"Banner_image":baseStr!]
        do {
            let body = try JSONSerialization.data(withJSONObject: disc, options: [])
            let url = URL(string: str)
            var request = URLRequest(url: url!)
            request.addValue(String(body.count), forHTTPHeaderField: "Content-Length")
            request.httpBody = body
            request.httpMethod = "POST"
            let session = URLSession.shared
            let datatask = session.dataTask(with: request){ (data1, resp, err) in
                let result = String(data: data1!, encoding: String.Encoding.utf8)
                print(result!)
                DispatchQueue.main.async {
                    if result == "success"
                    {
                        print(result)
                    }
                    else
                    {
                        print(result)
                    }
                }
                
            }
            datatask.resume()
        }catch  {
        }
    }
    // forfetching the data from plist
    func getPath() -> String {
        
        let arr = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        let path = arr[0]
        let finalPath = path.appending("/userLogin.plist")
        print(finalPath)
        return finalPath
    }
    func getLoginData() {
        
        let flm = FileManager()
        if flm.fileExists(atPath: getPath()) {
            
            var disc = NSDictionary(contentsOfFile: getPath()) as! [String:Any]
            brr = disc["userRecord"] as! [[String:Any]]
            let getDisc = brr[0];
            disc1 = getDisc;
        }
    }
    
    @objc func donedatePicker(){
        
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy/MM/dd"
    
        sdate.text = formatter.string(from: datepicker.date)
        
        self.view.endEditing(true)
    }
    
    @objc func cancelDatePicker(){
        self.view.endEditing(true)
    }
    @objc func donedatePicker1(){
        
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy/MM/dd"
       
        edate.text = formatter.string(from: datepicker.date)
        
        self.view.endEditing(true)
    }
    
    @objc func cancelDatePicker1(){
        self.view.endEditing(true)
    }

}
