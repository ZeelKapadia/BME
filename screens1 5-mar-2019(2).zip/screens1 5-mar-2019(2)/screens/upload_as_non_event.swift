
//
//  upload_as_non_event.swift
//  screens
//
//  Created by Zeel Kapadia on 25/01/19.
//  Copyright © 2019 TOPS. All rights reserved.
//

import UIKit
import Photos

class upload_as_non_event: UIViewController,UINavigationControllerDelegate,UIImagePickerControllerDelegate{
    var brr :[[String:Any]] = []
    var disc1 : [String:Any] = [:]
    var urlFinal = URL(string: "https://www.google.co.in/")
    var SelectedAssets : [PHAsset] = []
    var PhotoArray : [UIImage] = []
    var baseStrArray : [String] = []
    var responseStr : String = ""
    var flag : Int = 0
    
    
    @IBOutlet weak var img: UIImageView!

    override func viewDidLoad() {
        super.viewDidLoad()
        hidebars()
    }
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        if flag == 0 {
            img.image = info[UIImagePickerControllerOriginalImage] as? UIImage
            self.dismiss(animated: true, completion: nil)
        }else{
            let videourl = info[UIImagePickerControllerMediaURL] as! URL
            print(videourl)
            urlFinal = videourl
            do {
                let test =  try Data(contentsOf: videourl, options: Data.ReadingOptions.alwaysMapped)
                print(test)
            }catch{
            }
            img.image = getThumbnailImage(forUrl: videourl)
            self.dismiss(animated: true, completion: nil)
        }
    }
    func getThumbnailImage(forUrl url: URL) -> UIImage? {
        let asset: AVAsset = AVAsset(url: url)
        let imageGenerator = AVAssetImageGenerator(asset: asset)
        
        do {
            let thumbnailImage = try imageGenerator.copyCGImage(at:CMTimeMake(1, 60) , actualTime: nil)
            return UIImage(cgImage: thumbnailImage)
        } catch let error {
            print(error)
        }
        return nil
    }
    func hidebars() {
        self.navigationController?.navigationBar.isHidden = true
        self.tabBarController?.tabBar.isHidden = true
    }
   
    @IBAction func selectimage(_ sender: Any) {
        openGallary()
    }
    func openGallary()  {
        PhotoArray.removeAll()
        baseStrArray.removeAll()
        print(PhotoArray);
        print(baseStrArray)
        self.bs_presentImagePickerController(Vc, animated: true, select: { (assets : PHAsset) -> Void in
        }, deselect: { (asset : PHAsset) -> Void in
        }, cancel: { (assets : [PHAsset]) -> Void in
        }, finish: { (assets : [PHAsset]) -> Void in
            for i in 0..<assets.count{
                self.SelectedAssets.append(assets[i])
            }
            self.convertAssetsToImages()
        }, completion: nil)
    }
    func convertAssetsToImages() {
        if SelectedAssets.count != 0 {
            for i in 0..<SelectedAssets.count{
                let manager = PHImageManager()
                let option = PHImageRequestOptions()
                var Thumbnail = UIImage()
                option.isSynchronous = true
                manager.requestImage(for: SelectedAssets[i], targetSize: CGSize(width: 200, height: 200), contentMode: .aspectFill, options: option) { (result, info) in
                    Thumbnail = result!
                }
                let imgData = UIImagePNGRepresentation(Thumbnail)
                let baseStr = imgData?.base64EncodedString(options: Data.Base64EncodingOptions.lineLength64Characters)
                self.baseStrArray.append(baseStr!)
                let data = UIImagePNGRepresentation(Thumbnail)
                let newImage = UIImage(data: data!)
                self.PhotoArray.append(newImage! as UIImage)
            }
            //  DispatchQueue.main.async {
            self.img.animationImages = self.PhotoArray
            self.img.animationDuration = 5.0
            self.img.startAnimating()
            //   }
        }
    }
    
    @IBAction func selectvideo(_ sender: Any) {
        Media()
    }
    func Media() {
        
        let picker = UIImagePickerController()
        picker.sourceType = .photoLibrary
        picker.mediaTypes = [kUTTypeMovie as String]
        picker.delegate = self
        self.flag = 1
        self.present(picker, animated: true, completion: nil)
    }
    
    
    @IBAction func Upload(_ sender: Any) {
        if flag == 0{
            uploadimg()
            moveToOriginalTab()
        }
        else if flag == 1{
            uploadvideo()
            moveToOriginalTab()
        }
    }
        func moveToOriginalTab() {
            let stb = self.storyboard?.instantiateViewController(withIdentifier: "participanttab")
            self.navigationController?.pushViewController(stb!, animated: true)
    }
        func uploadimg() {
            //if baseStrArray.count >= 1
            // {
            for item in baseStrArray {
                
                let str = "http://localhost/votingdb/uploadAsNonEvent.php"
                
                let disc : [String:Any] = ["pa_id":disc1["user_id"]!, "flag":flag, "Image_data":item]
                do{
                    let body = try JSONSerialization.data(withJSONObject: disc, options: [])
                    let url = URL(string: str)
                    var request = URLRequest(url: url!)
                    request.addValue(String(body.count), forHTTPHeaderField: "Content-Length")
                    request.httpBody = body
                    request.httpMethod = "POST"
                    let session = URLSession.shared
                    let dataTask = session.dataTask(with: request) { (data1, resp1, err) in
                        
                        let result = String(data: data1!, encoding: String.Encoding.utf8)
                        print(result!)
                        self.responseStr = result!
                        DispatchQueue.main.async {
                            
                            if self.responseStr == "Inserted"{
                                
                                print("Success!")
                            }
                        }
                    }
                    dataTask.resume()
                }catch{
                }
            }
        }
        //}
        // for uploading videos
        func uploadvideo() {
            do{
                let videoData = try Data(contentsOf: urlFinal!, options: Data.ReadingOptions.alwaysMapped)
                let baseStr = videoData.base64EncodedString(options: Data.Base64EncodingOptions.lineLength64Characters)
                
                let str = "http://localhost/votingdb/upload.php"
                let disc : [String : Any] = ["pa_id":disc1["user_id"]!,"flag":flag,"video_data":baseStr]
                do {
                    let body = try JSONSerialization.data(withJSONObject: disc, options: [])
                    let url = URL(string: str)
                    var request = URLRequest(url: url!)
                    
                    request.addValue(String(body.count), forHTTPHeaderField: "Content-Length")
                    request.httpBody = body
                    request.httpMethod = "POST"
                    
                    let session = URLSession.shared
                    let dataTask = session.dataTask(with: request, completionHandler: { (data1, resp1, err) in
                        
                        let result = String(data: data1!, encoding: String.Encoding.utf8)
                        print(result!)
                        
                        DispatchQueue.main.async {
                            
                            if result == "Inserted"{
                                
                                print("Success")
                            }
                        }
                    })
                    dataTask.resume()
                    
                } catch  {}
            }catch{}
        }
    func getPath() -> String {
        
        let arr = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        let path = arr[0]
        let finalPath = path.appending("/userLogin.plist")
        print(finalPath)
        return finalPath
    }
    func getLoginData() {
        
        let flm = FileManager()
        if flm.fileExists(atPath: getPath()) {
            
            var disc = NSDictionary(contentsOfFile: getPath()) as! [String:Any]
            brr = disc["userRecord"] as! [[String:Any]]
            let getDisc = brr[0];
            disc1 = getDisc;
            
        }
    }
}

