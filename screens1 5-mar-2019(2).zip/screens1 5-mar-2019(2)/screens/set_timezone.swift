import UIKit
class set_timezone: UIViewController {
   
    @IBOutlet weak var sdate: UIDatePicker!
    @IBOutlet weak var edate: UIDatePicker!
 // /Users/zeelkapadia/Desktop/bme 16-1-2019/screens/screens/signup.swift
    
    var sdate1 = "";
    var edate1 = "";
    var eventid = "";
    var userid = "";
    var getuid = ""
 //   var min :Date?;
  //  var max :Date?;
    
    @IBOutlet weak var startingdate: UITextField!
    @IBOutlet weak var endingdate: UITextField!
    @IBOutlet weak var btnCTZ: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        btnCTZ.layer.cornerRadius = btnCTZ.layer.frame.height / 2;
        btnCTZ.clipsToBounds = true
        hidebars()
    }
   
    func setTime() {
//        sdate.minimumDate = min;
//        sdate.maximumDate = max;
//        edate.minimumDate = min;
//        edate.maximumDate = max;
    }
    func hidebars() {
        self.navigationController?.navigationBar.isHidden = true
     //   self.tabBarController?.tabBar.isHidden = true
    }
    @IBAction func startdate(_ sender: Any) {
        let str = sdate.date
        let frm = DateFormatter()
        frm.dateFormat = "yyyy-MM-dd";
        sdate1 = frm.string(from: str);
        startingdate.text = sdate1;
    }
    
    @IBAction func enddate(_ sender: Any) {
        let str = edate.date
        let frm = DateFormatter()
        frm.dateFormat = "yyyy-MM-dd";
        edate1 = frm.string(from: str);
        endingdate.text = edate1;
    }
    func checkData() {
        if startingdate.text == ""{
            if endingdate.text == ""{
                let alt = UIAlertController(title: "Empty Field Found", message: "You must have to set the Ending time for the Checkin time for the user", preferredStyle: .alert)
                let ok = UIAlertAction(title: "Ok", style: .default, handler: nil)
                alt.addAction(ok)
                self.present(alt, animated: true, completion: nil)
            }
            let alt = UIAlertController(title: "Empty Field Found", message: "You must have to set the Starting time for the Checkin time for the user", preferredStyle: .alert)
            let ok = UIAlertAction(title: "Ok", style: .default, handler: nil)
            alt.addAction(ok)
            self.present(alt, animated: true, completion: nil)
        }
    }
    @IBAction func btn_insert_date(_ sender: Any) {
     //   settimeforevent()
        checkData()
        create_time_zone()
       moveonOrgpanel()
    }
    func moveonOrgpanel() {
        let stb = self.storyboard?.instantiateViewController(withIdentifier: "org_tab")
        self.navigationController?.pushViewController(stb!, animated: true)
    }
    func create_time_zone()  {
     
        let str = "http://localhost/votingdb/votingManage.php"
        let disc : [String : Any] = ["E_id" : eventid, "user_id" : userid ,"Start_time" : startingdate.text!, "End_time" : endingdate.text!];
        do {
            
            let body = try JSONSerialization.data(withJSONObject: disc, options: [])
            let url = URL(string: str)
            var request = URLRequest(url: url!)
            
            request.addValue(String(body.count), forHTTPHeaderField: "Content-Length")
            request.httpBody = body
            request.httpMethod = "POST"
            
            let session = URLSession.shared
            let datatask = session.dataTask(with: request){ (data1, resp, err) in
                
                let result = String(data: data1!, encoding: String.Encoding.utf8)
                print(result!)
                do{
                    let jsonData = try JSONSerialization.jsonObject(with: data1!, options: []) as! [[String:Any]]
                    
                    DispatchQueue.main.async {
                        if jsonData.count == 1
                        {
                            let alt = UIAlertController(title: "Confirmation", message: "your time zone is created Successfully", preferredStyle: .alert)
                            
                            let ok1 = UIAlertAction(title: "OK", style: .default, handler: { (dt) in
                                
                                let st = self.storyboard?.instantiateViewController(withIdentifier: "org_tab")
                                self.navigationController?.pushViewController(st!, animated: true)
                                
                            })
                            alt.addAction(ok1);
                            self.present(alt, animated: true, completion:nil)
                        }
                        else
                        {
                            let alt = UIAlertController(title: "Alert Message", message: "the time zone is not created", preferredStyle: .alert)
                            let ok1 = UIAlertAction(title: "OK", style: .default, handler: { (dt) in
                                
                                let st = self.storyboard?.instantiateViewController(withIdentifier: "org_tab")
                                self.navigationController?.pushViewController(st!, animated: true)
                        })
                            alt.addAction(ok1);
                            self.present(alt, animated: true, completion:nil)
                        }
                    }
                }catch{
                }
            }
            datatask.resume()
        }catch  {
        }
    }
}
