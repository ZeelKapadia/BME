
//
//  forget_password.swift
//  screens
//
//  Created by Zeel Kapadia on 24/01/19.
//  Copyright © 2019 TOPS. All rights reserved.
//

import UIKit

class forget_password: UIViewController,DataUpdatedDelegate{
    
    func Update(str: String) {
        print(str);
    }
    
    func UpdateAgain(str: String) {
        
    }
    
    @IBOutlet weak var user_email: UITextField!
    @IBOutlet weak var btnConfirm: UIButton!
    var number = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        btnConfirm.layer.cornerRadius = btnConfirm.layer.frame.height / 2;
        btnConfirm.clipsToBounds = true
    }
    
  
    func moveNextPage() {
        let stb = storyboard?.instantiateViewController(withIdentifier: "confirmation") as! confirmation
        stb.user_email = user_email.text!
        self.navigationController?.pushViewController(stb, animated: true)
    }
    func generateRandomDigits(_ digitNumber: Int) -> String {
     for i in 0..<digitNumber {
     var randomNumber = arc4random_uniform(10)
     while randomNumber == 0 && i == 0 {
     randomNumber = arc4random_uniform(10)
     }
     number += "\(randomNumber)"
     }
     return number
     }
    
    func insert() {
        let objUpdate = DataUpdate()
        objUpdate.delegate = self
        let disc :[String:Any] = ["otp":number,"user_email":user_email.text!]
        objUpdate.RecordUpdate(FileName: "OTP.php", DiscData: disc)
    }
    func check() {
        if user_email.text == "" {
            let alt = UIAlertController(title: "the field cannot be empty", message: "you must have to enter your email id", preferredStyle: .actionSheet)
            let ok = UIAlertAction(title: "OK", style: .default, handler: nil)
            alt.addAction(ok);
            self.present(alt, animated: true, completion: nil)
        }
        else{
            let OTP = generateRandomDigits(6)
            _ = SweetAlert().showAlert("Good job!", subTitle: "Kindly find your OTP \(OTP)", style: AlertStyle.success)
            insert()
            moveNextPage()
        }
    }
     @IBAction func btnGetCodeAgain(_ sender: Any) {
        check()
     }
}
