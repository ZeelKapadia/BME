import UIKit

class show_user : UIViewController,UITableViewDataSource,UITableViewDelegate,UINavigationBarDelegate,FetchDelegate {
    func getResponseData(arrDisc: [[String : Any]]) {
        if arrDisc.count > 0 {
            Aodisc = arrDisc
        }
        tbluserinfo.reloadData()
    }
    
    func getResponseDataAgain(arrDisc: [[String : Any]]) {
        
    }
    
    
    @IBOutlet weak var SegChangeRole: UISegmentedControl!
    @IBOutlet weak var tbluserinfo: UITableView!
    var Aodisc :  [[String:Any]] = [];
    
    override func viewWillAppear(_ animated: Bool) {
        SegChangeRole.selectedSegmentIndex = 0
        //self.navigationController?.navigationBar.isHidden = true
        //self.tabBarController?.tabBar.isHidden = true
    }
    func hidebars() {
        self.navigationController?.navigationBar.isHidden = true
        self.tabBarController?.tabBar.isHidden = true
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return Aodisc.count
    }
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete{
            self.Aodisc.remove(at: indexPath.row)
            tableView.reloadData();
        }
    }
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true;
    }
    func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]? {
        let block = UITableViewRowAction(style: .destructive, title: "block"){(rowaction,indexPath)in}
        let delete = UITableViewRowAction(style: .default, title: "delete"){(rowaction,indexPath)in}
        return [block,delete];
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        print(self.Aodisc)
        let disc = Aodisc[indexPath.row]
        
         cell.textLabel?.text = disc["user_fname"] as? String;
       cell.detailTextLabel?.text = disc["user_type"] as? String;
        return cell;
    }


    @IBAction func btn_menu(_ sender: Any) {
        let stb = storyboard?.instantiateViewController(withIdentifier: "org_menu") as! org_menu;
        self.navigationController?.pushViewController(stb, animated: true)
    }
    @IBAction func SegmentChangState(_ sender: Any) {
        self.navigationController?.navigationBar.isHidden = true
        self.tabBarController?.tabBar.isHidden = true
        if SegChangeRole.selectedSegmentIndex == 0{
            let stb = storyboard?.instantiateViewController(withIdentifier: "org_tab")
            self.navigationController?.pushViewController(stb!, animated: true)
        }
        if SegChangeRole.selectedSegmentIndex == 1 {
            let stb = self.storyboard?.instantiateViewController(withIdentifier: "participanttab")
            self.navigationController?.pushViewController(stb!, animated: true);
        }
        else if SegChangeRole.selectedSegmentIndex == 2{
            let stb = self.storyboard?.instantiateViewController(withIdentifier: "Usertab")
            self.navigationController?.pushViewController(stb!, animated: true);
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.navigationBar.isHidden = false;
        show_user_data()
    }
    // for showing the user information to the organizer
    func show_user_data() {
    let objClass = dataFetch()
        objClass.delegate = self
        objClass.fetch_data(Filename: "UserFetch.php")
    }
    
    
}
