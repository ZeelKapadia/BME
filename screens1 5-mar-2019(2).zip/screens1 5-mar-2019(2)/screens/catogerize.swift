import UIKit

class catogerize: UIViewController,UITableViewDataSource, UITableViewDelegate {
    let arr = ["Dancing","Singing","Acting","Drama","Mimicry"];
    var uType :String = ""
        override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arr.count;
        
    }
    
    @IBAction func btnmove(_ sender: Any) {
        placeTab()
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        cell.textLabel?.text = arr[indexPath.row];
        return cell;
    }
    func placeTab() {
        
    }
    func getPath() -> String {
        
        let arr = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        let path = arr[0]
        let finalPath = path.appending("/userLogin.plist")
        print(finalPath)
        return finalPath
    }
    func getLoginData() {
        
        let flm = FileManager()
        if flm.fileExists(atPath: getPath()) {
            
            var disc = NSDictionary(contentsOfFile: getPath()) as! [String:Any]
           let brr = disc["userRecord"] as! [[String:Any]]
            let getDisc = brr[0];
            uType = getDisc["user_type"]as! String;
            
        }
    }
}
