import UIKit

class cellformenu: UITableViewCell {

    @IBOutlet weak var imgcircle: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        imgcircle.layer.cornerRadius = imgcircle.layer.borderWidth/2
        imgcircle.layer.masksToBounds = true
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

       
    }
    
}
