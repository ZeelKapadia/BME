import UIKit

class AddDetails: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

    
    }
    

}
