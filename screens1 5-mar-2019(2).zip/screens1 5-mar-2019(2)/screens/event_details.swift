//
//  event_details.swift
//  screens
//
//  Created by Zeel Kapadia on 12/01/19.
//  Copyright © 2019 TOPS. All rights reserved.
//
import SDWebImage

import UIKit

class event_details: UIViewController,DataUpdatedDelegate{
    func Update(str: String) {
        
    }
    
    func UpdateAgain(str: String) {
        
    }
    
    
    var discForEvent : [String:Any] = [:]
    //var arrTime : [[String:Any]] = []
    var arrEvent : [[String:Any]] = []
    var discForTime : [String:Any] = [:]
    var participant : String = ""

    
    @IBOutlet weak var btnUpload: UIButton!
    @IBOutlet weak var btnHome: UIButton!
    @IBOutlet weak var img_data: UIImageView!
    @IBOutlet weak var event_name: UILabel!
    @IBOutlet weak var starting_time: UILabel!
    @IBOutlet weak var ending_time: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
      getLoginData()
       dataupdate()
        showdata()
        
        btnHome.layer.cornerRadius = btnHome.layer.frame.height / 2;
        btnHome.clipsToBounds = true
        btnUpload.layer.cornerRadius = btnUpload.layer.frame.height / 2;
        btnUpload.clipsToBounds = true
    }
    func  dataupdate() {
    let objClass = DataUpdate()
        objClass.delegate = self
        discForTime = ["E_id":discForEvent["E_id"] as! String,"P_id":participant]
        objClass.RecordUpdate(FileName: "eventUpdateParticipantId.php", DiscData:discForTime)
    }
    func getPath() -> String {
        let arr = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        let path = arr[0]
        let finalPath = path.appending("/userLogin.plist")
        print(finalPath)
        return finalPath
    }
    func getLoginData() {
        
        let flm = FileManager()
        if flm.fileExists(atPath: getPath()) {
            
            var disc = NSDictionary(contentsOfFile: getPath()) as! [String:Any]
            let arr = disc["userRecord"] as! [[String:Any]]
           let brr = arr[0];
            participant = brr["user_id"] as! String;
        }
    }
    func showdata() {
        event_name.text = discForEvent["E_name"] as? String
        starting_time.text = discForEvent["Starting_date"] as? String
        ending_time.text = discForEvent["Ending_date"] as? String
        let imgData = discForEvent["Banner_image"] as! String;
        let url = "http://localhost/votingdb/"
        let strUrl = url + imgData
        let finalUrl = URL(string: strUrl)
        do{
            let imgData = try Data(contentsOf: finalUrl!)
            img_data.image = UIImage(data: imgData)
        }catch{
        }
    }
    
    @IBAction func btn_apply(_ sender: Any) {
      
        let stb = storyboard?.instantiateViewController(withIdentifier: "Upload") as! Upload
        stb.e_id = discForEvent["E_id"] as! String
        self.navigationController?.pushViewController(stb, animated: true)
    }
    
    @IBAction func backToHome(_ sender: Any) {
        let stb = storyboard?.instantiateViewController(withIdentifier: "participanttab")
        self.navigationController?.pushViewController(stb!, animated: true)
    }
}
