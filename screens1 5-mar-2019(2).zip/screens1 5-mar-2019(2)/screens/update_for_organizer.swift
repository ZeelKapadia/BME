//
//  update_for_organizer.swift
//  screens
//
//  Created by Zeel Kapadia on 23/01/19.
//  Copyright © 2019 TOPS. All rights reserved.
//

import UIKit

class update_for_organizer: UIViewController,UINavigationControllerDelegate,UIImagePickerControllerDelegate {
    
    @IBOutlet weak var img: UIImageView!
    
    @IBOutlet weak var txtemail: UITextField!
    @IBOutlet weak var txtlname: UITextField!
    @IBOutlet weak var txtfname: UITextField!
    
    var brr : [String:Any] = [:]
    
    var updatedData : [[String:Any]] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        img.layer.cornerRadius = img.layer.frame.size.width  / 2;
        img.clipsToBounds = true;
        getLoginData()
        showdata()
        hidebars()
       
    }
    func hidebars() {
        self.navigationController?.navigationBar.isHidden = true
        self.tabBarController?.tabBar.isHidden = true
    }
    func getPath() -> String {
        let arr = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        let path = arr[0]
        let finalPath = path.appending("/userLogin.plist")
        print(finalPath)
        return finalPath
    }
    func getLoginData() {
        
        let flm = FileManager()
        if flm.fileExists(atPath: getPath()) {
            
            var disc = NSDictionary(contentsOfFile: getPath()) as! [String:Any]
            let arr = disc["userRecord"] as! [[String:Any]]
            brr = arr[0] ;
            
        }
    }
    func showdata() {
        txtfname.text = brr["user_fname"] as? String;
        txtlname.text = brr["user_lname"] as? String;
        txtemail.text = brr["user_email"] as? String;
        let imgData = brr["image"] as! String;
        let url = "http://localhost/votingdb/"
        let strUrl = url + imgData
        let finalUrl = URL(string: strUrl)
        do{
            let imgData = try Data(contentsOf: finalUrl!)
            img.image = UIImage(data: imgData)
        }catch{
        }
    }
    @IBAction func upload_image(_ sender: Any) {
    alert()
    }
    func alert() {
        let alt = UIAlertController(title: "Add your profile", message: "Select any option", preferredStyle: .alert)
        let camera = UIAlertAction(title: "Camera", style: .default, handler: {action in
            let picker = UIImagePickerController()
            picker.sourceType = .camera
            picker.delegate = self;
            self.present(picker,animated: true,completion: nil)
        })
        let gallery = UIAlertAction(title: "Gallery", style: .default, handler: {action in
            let picker = UIImagePickerController()
            picker.sourceType = .photoLibrary
            picker.delegate = self;
            self.present(picker,animated: true,completion: nil)
        })
        alt.addAction(camera);
        alt.addAction(gallery);
        
        
        self.present(alt, animated: true, completion: nil)
    }
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        let img1 = info[UIImagePickerControllerOriginalImage] as! UIImage;
        img.image = img1;
        self.dismiss(animated: true, completion: nil);
        
    }
    func updateUser()  {
        
        let imgData = UIImagePNGRepresentation(img.image!)
        let baseStr = imgData?.base64EncodedString(options: Data.Base64EncodingOptions.lineLength64Characters)
        
        let str = "http://localhost/votingdb/UserUpdateProfile.php"
        let disc : [String : Any] = ["user_id":brr["user_id"]!,"user_fname":txtfname.text!,"user_lname":txtlname.text!,"user_email":txtemail.text!,"image":baseStr!]
        do {
            
            let body = try JSONSerialization.data(withJSONObject: disc, options: [])
            let url = URL(string: str)
            var request = URLRequest(url: url!)
            
            request.addValue(String(body.count), forHTTPHeaderField: "Content-Length")
            request.httpBody = body
            request.httpMethod = "POST"
            
            let session = URLSession.shared
            let datatask = session.dataTask(with: request){ (data1, resp, err) in
                
                let result = String(data: data1!, encoding: String.Encoding.utf8)
                print(result!)
                do{
                    let jsonData = try JSONSerialization.jsonObject(with: data1!, options: []) as! [[String:Any]]
                    self.updatedData = jsonData
                    DispatchQueue.main.async {
                        
                        if jsonData.count == 1
                        {
                            self.updateplist()
                            let alt = UIAlertController(title: "Alert message", message: "your information is updated Successfully", preferredStyle: .alert)
                            
                            let ok1 = UIAlertAction(title: "OK", style: .default, handler: { (dt) in
                                
                                let st = self.navigationController?.popToRootViewController(animated: true);
                                print(st!);
                            })
                            alt.addAction(ok1);
                            self.present(alt, animated: true, completion:nil)
                        }
                        else
                        {
                            let alt = UIAlertController(title: "Confirmation", message: "your record not updated", preferredStyle: .alert)
                            let ok1 = UIAlertAction(title: "OK", style: .default, handler: { (dt) in
                                let st = self.navigationController?.popToRootViewController(animated: true)
                                print(st!)
                            })
                            alt.addAction(ok1);
                            self.present(alt, animated: true, completion:nil)
                        }
                    }
                }catch{
                }
            }
            datatask.resume()
        }catch  {
        }
    }
  

  
    @IBAction func updaterecords(_ sender: Any) {
     updateUser()
    }
    func updateplist() {
        let flm = FileManager()
        if flm.fileExists(atPath: getPath()) {
            
            var disc = NSDictionary(contentsOfFile: getPath()) as! [String:Any]
            var arr = disc["userRecord"] as! [[String:Any]]
            arr = updatedData;
            disc["userRecord"] = arr
            let finalDisc = NSDictionary(dictionary: disc)
            finalDisc.write(toFile: getPath(), atomically: true)
        }
    }
}
